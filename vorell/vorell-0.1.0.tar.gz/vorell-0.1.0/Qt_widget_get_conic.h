// Copyright (c) 1997-2000  Utrecht University (The Netherlands),
// ETH Zurich (Switzerland), Freie Universitaet Berlin (Germany),
// INRIA Sophia-Antipolis (France), Martin-Luther-University Halle-Wittenberg
// (Germany), Max-Planck-Institute Saarbruecken (Germany), RISC Linz (Austria),
// and Tel-Aviv University (Israel).  All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License as
// published by the Free Software Foundation; version 2.1 of the License.
// See the file LICENSE.LGPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $Source: /0/user/teillaud/cvsroot/Curved_kernel/Curved_kernel/demo/Curved_kernel/Qt_widget_get_conic.h,v $
// $Revision: 1.7 $ $Date: 2004/03/22 13:04:27 $
// $Name:  $
//
// Author(s)     : Radu Ursu

// Modified by Constantinos Tsirogiannis for the Voronoi Diagram of Ellipses GUI

// Modified by George M. Tzoumas for the Voronoi Diagram of Ellipses GUI

#ifndef CGAL_QT_WIDGET_GET_CONIC_H
#define CGAL_QT_WIDGET_GET_CONIC_H

#include <CGAL/IO/Qt_widget.h>
#include <CGAL/IO/Qt_widget_layer.h>
#include <CGAL/IO/Qt_widget_Conic_2.h>
#include <CGAL/simplest_rational_in_interval.h>
#include <CGAL/gmpxx.h>
#include <qcursor.h>

#ifndef CGAL_QT_WIDGET_GET_POINT_BUTTON
#define CGAL_QT_WIDGET_GET_POINT_BUTTON Qt::LeftButton
#endif

#include "ellipse_decompiler.h"

namespace CGAL {

class Qt_widget_get_conic_helper
  : public CGAL::Qt_widget_layer
{
Q_OBJECT

public:

  Qt_widget_get_conic_helper(QObject* parent = 0, const char* name = 0)
    : Qt_widget_layer(parent, name) {}

  virtual void got_it()
  {
    emit new_object_time(); 
  }

signals:
  void new_object_time();
};


template <class R>
class Qt_widget_get_conic : public Qt_widget_get_conic_helper
{
  enum PhaseEnum { 
    INIT_SUPPORT = 0,
    TRACE_SUPPORT,
    //TRACE_SOURCE,
    //TRACE_TARGET,
    ARC_DONE
  };

  public:
  typedef typename R::Point_2	     Point;
  typedef typename R::Segment_2    Segment;
  typedef typename R::Line_2       Line_2;
  typedef typename CGAL::Conic_2<R>  Conic_2;
  typedef typename R::FT	     FT;

  Qt_widget_get_conic(const QCursor c=QCursor(Qt::crossCursor),
      QObject* parent = 0, const char* name = 0) :
    Qt_widget_get_conic_helper(parent, name), cursor(c) {};

  void draw()
  {
    widget->lock();
    QColor old_color = widget->color();
    switch( phase )
    {
      case ARC_DONE:
	*widget << CGAL::BLUE << segment2;
	phase = INIT_SUPPORT;
      //case TRACE_TARGET:
	//*widget << CGAL::BLUE << segment1;
      //case TRACE_SOURCE:
	//*widget << CGAL::GREEN << CGAL::LineWidth(1);
	//*widget << oldconic;
	//*widget << CGAL::RED << CGAL::PointSize(3);
	//	  assert ( p_vector.size() == 5); 
      case TRACE_SUPPORT:
      case INIT_SUPPORT:
	*widget << CGAL::RED << CGAL::PointSize(3);
	for(unsigned int i=0; i<p_vector.size(); i++)
	  *widget << p_vector[i];
      default:break;
    }
    widget->unlock();
    widget->setColor(old_color);
  }

  Conic_2 get_conic() 
  {
    bool b1 = ( segment1.min() == segment1.target() );
    bool b2 = ( segment2.min() == segment2.target() );
    Line_2 l1 (segment1);
    Line_2 l2 (segment2);
    return Conic_2(oldconic, l1, b1, l2, b2);
  }

protected:

  bool is_pure(Qt::ButtonState s)
  {
    if((s & Qt::ControlButton) ||
	(s & Qt::ShiftButton) ||
	(s & Qt::AltButton))
      return 0;
    else
      return 1;
  }
  
  typedef CGAL::Quotient< ::mpz_class > CGAL_Rational;
     
  void x_real(int x, ::mpq_class& return_t) const
  {
    if(widget->x_scal()<1)
      return_t = ( widget->x_min()+(int)(x/widget->x_scal()) );
    else
    {
      CGAL_Rational r = CGAL::simplest_rational_in_interval< CGAL_Rational > (
	  widget->x_min()+x/widget->x_scal()-(x/widget->x_scal()-(x-1)/widget->x_scal())/2,
	  widget->x_min()+x/widget->x_scal()+((x+1)/widget->x_scal()-x/widget->x_scal())/2);
      return_t = ( CGAL::to_double(r) );
    }
  }

  void y_real(int y, mpq_class& return_t) const
  {
    if(widget->y_scal()<1)
      return_t = (widget->y_max()-(int)(y/widget->y_scal()));
    else
    {
      CGAL_Rational r = CGAL::simplest_rational_in_interval<CGAL_Rational>(
	  widget->y_max() - y/widget->y_scal()-(y/widget->y_scal()-(y-1)/widget->y_scal())/2,
	  widget->y_max() - y/widget->y_scal()+((y+1)/widget->y_scal()-y/widget->y_scal())/2);
      return_t = (CGAL::to_double(r));
    }
  }

  void mousePressEvent(QMouseEvent *e)
  {
    if(e->button() == Qt::LeftButton
	&& is_pure(e->state()))
    {
      FT x, y;
      widget->x_real(e->x(), x);
      widget->y_real(e->y(), y);
//      std::cerr << "gotcha! " << x << "," << y << std::endl;
      Point p(x, y);

      animate = false;

      switch( phase )
      {
	case ARC_DONE:
	  phase = INIT_SUPPORT;
	case INIT_SUPPORT:		// Get 4 points from mouse clicks
	  p_vector.push_back(p);
	  *widget << p;
          if (p_vector.size() == 3) {
              
              EllipseDecompiler ed(tQQ(p_vector[0].x()), tQQ(p_vector[0].y()), tQQ(p_vector[1].x()), tQQ(p_vector[1].y()), 
                      tQQ(p_vector[2].x()), tQQ(p_vector[2].y()));
              widget->new_object(make_object(ed));
              p_vector.clear();
              got_it();
              phase = ARC_DONE;
              draw();
          }
/*	  if ( p_vector.size() == 4)  // On 4th point start tracing the support
	  {
	   // widget->new_object(make_object(oldconic)); 
	    phase = TRACE_SUPPORT;
	  }*/
	  break;
/*	case TRACE_SUPPORT:		// If tracing support, anchor it and
	  // To prevent the ctor to fail. ignore point
	  if (p == p_vector[0] || p == p_vector[1] || p == p_vector[2] || p == p_vector[3]) 
	    break;
	  p_vector.push_back(p);
	  *widget << p;
	  assert (  p_vector.size() == 5 );
	  oldconic.set(p_vector[0], p_vector[1], p_vector[2], p_vector[3], p_vector[4]);
	  leaveEvent(e);
	  if ( oldconic.is_ellipse() )// if conic is ellipse 
	  {
	    FT det =  oldconic.s()*oldconic.r()*4 - oldconic.t()*oldconic.t();
	    center_of_ellipse = Point(
		FT((oldconic.t()*oldconic.v() - oldconic.s()*oldconic.u()*2)/det),
		FT((oldconic.t()*oldconic.u() - oldconic.r()*oldconic.v()*2)/det)
				     );
	    old_segment = Segment(center_of_ellipse, p);
	    //phase = TRACE_SOURCE;	// Start tracing the source line
	  }
	  else
	  {
	    p_vector.clear();		// else restart
	    std::cerr << " Not an ellipse " << std::endl;
	    phase = INIT_SUPPORT;
	  }

          widget->new_object(make_object(oldconic));
          p_vector.clear();
          got_it();
          phase = ARC_DONE; //////////////////////////////////$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
          draw();


	  break;*/
	//case TRACE_SOURCE: 		// If tracing the source line, anchor it and 
	//  segment1 = segment2 = old_segment;
	//  leaveEvent(e);
	//  phase = TRACE_TARGET;	// Start tracing the target line
	//  break;
	//case TRACE_TARGET:		// If tracing the target line, anchor it and
	//  segment2 = old_segment;
	//  leaveEvent(e);
	//  p_vector.clear();		// Clean up points, Arc gotten
	//  got_it();
	// phase = ARC_DONE;
	//  break;
      }
      widget->redraw();
    }
  }

  void leaveEvent(QEvent *e)
  {
    RasterOp old_raster;
    QColor old_color;

    animate = false;
    switch( phase )
    {
      case TRACE_SUPPORT: // Anchor oldconic
	widget->lock();
	old_raster = widget->rasterOp();//save the initial raster mode
	old_color = widget->color();
	widget->setRasterOp(XorROP);
	*widget << CGAL::GREEN << CGAL::PointSize(1);
	*widget << oldconic;
	widget->setRasterOp(old_raster);
	widget->setColor(old_color);
	widget->unlock();
	break;
      //case TRACE_SOURCE: // Anchor old_segment
      //case TRACE_TARGET:
	//widget->lock();
	//old_raster = widget->rasterOp();//save the initial raster mode
	//old_color = widget->color();
	//widget->setRasterOp(XorROP);
	//*widget << CGAL::BLUE;
	//*widget << old_segment;
	//widget->setRasterOp(old_raster);
	//widget->setColor(old_color);       
	//widget->unlock();
	//break;
      default:
	break;
    }
  }

  void mouseMoveEvent(QMouseEvent *e)
  {
    FT x, y;
    RasterOp old_raster;
    QColor old_color;
    widget->x_real(e->x(), x);
    widget->y_real(e->y(), y);
    Point p(x, y);

    switch( phase )
    {
      case TRACE_SUPPORT: // Trace oldconic
	widget->lock();
	old_raster = widget->rasterOp();//save the initial raster mode
	old_color = widget->color();
	widget->setRasterOp(XorROP);
	*widget << CGAL::GREEN << CGAL::PointSize(1);
	assert ( p_vector.size() == 4);
	if( animate ) // in animate loop 
	  *widget << oldconic;
	animate = true;
	// To prevent the ctor to fail.
	if (p != p_vector[0] && p != p_vector[1] && p != p_vector[2] && p != p_vector[3]) 
	{
	  //save the last conic to redraw the screen
	  oldconic.set(p_vector[0], p_vector[1], p_vector[2], p_vector[3], Point(x, y));
	}
	*widget << oldconic;
	widget->setRasterOp(old_raster);
	widget->setColor(old_color);
	widget->unlock();
	break;
      //case TRACE_SOURCE: // Trace old_segment
      //case TRACE_TARGET:
	//widget->lock();
	//old_raster = widget->rasterOp();//save the initial raster mode
	//old_color = widget->color();
	//widget->setRasterOp(XorROP);
	//*widget << CGAL::BLUE;
	//if( animate ) // in animate loop 
	  //*widget << old_segment;
	//animate = true;
	//if (p != center_of_ellipse ) // To prevent the ctor to fail.
	  //old_segment = Segment(center_of_ellipse, p);
	//*widget << old_segment;
	//widget->setRasterOp(old_raster);
	//widget->setColor(old_color);       
	//widget->unlock();
	//break;
      default:
	break;
    }
  }

  void keyPressEvent(QKeyEvent *e)
  {
    switch ( e->key() ) {
      case Key_Escape:			// key_escape
	p_vector.clear();		// Clean up points, restart 
	phase = INIT_SUPPORT;
	widget->redraw();
	break;
    }//endswitch
  }

  void activating()
  {
    oldpolicy = widget->focusPolicy();
    widget->setFocusPolicy(QWidget::ClickFocus);
    oldcursor = widget->cursor();
    widget->setCursor(cursor);
    animate = false;
    phase = INIT_SUPPORT;
  }

  void deactivating()
  {
    widget->setCursor(oldcursor);
    widget->setFocusPolicy(oldpolicy);
    p_vector.clear();
    animate = false;
    phase = INIT_SUPPORT;
  }

  QCursor cursor;
  QCursor oldcursor;
  std::vector<Point> p_vector;
  Conic_2  oldconic;
  Point    center_of_ellipse;
  Segment  old_segment, segment1, segment2;
  int   phase;
  bool  animate;
  QWidget::FocusPolicy	oldpolicy;
};

} // namespace CGAL

#endif // CGAL_QT_WIDGET_GET_CONIC_H
