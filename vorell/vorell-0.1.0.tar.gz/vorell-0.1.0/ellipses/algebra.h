/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _ALGEBRA_H_
#define _ALGEBRA_H_

//#include <algebramix/dense_polynomial.hpp>

#include <algebrix/kernel_texp.hpp>
#include <realroot/kernel.hpp>

#include "NCF.hpp"

#include <algebrix/mpoldst.hpp>
#include <algebrix/upoldse.hpp>
#include <algebrix/matrdse.hpp>
#include <algebrix/resultant.hpp>
#include <algebrix/Det.hpp>

using namespace mmx;

typedef ACS_AK_Ring AK;
typedef AK::AlgebraicReal_1 Root;
typedef AK::AlgebraicRealSet_1 RootSeq;

typedef monomial<ZZ>  monomz_t;
typedef monomial<QQ> monomq_t;
//typedef monomial<double>  monomx_t;

typedef mpoldst<ZZ>  mpolz_t;
typedef mpoldst<QQ> mpolq_t;
//typedef mpoldst<double>  mpolx_t;

typedef upoldse<ZZ>  upolz_t;
typedef upoldse<QQ> upolq_t;
typedef upoldse<double>  upolx_t;

typedef matrdse<ZZ> matz_t;
typedef matrdse<QQ> matq_t;
typedef matrdse<ZZ> matmpolz_t;
typedef matrdse<QQ> matmpolq_t;

//void seq_primpart(int len, QQ *p, ZZ *c);
upolz_t primpart(const upolq_t p);
upolz_t primpart(const upolz_t p);
mpolz_t primpart(mpolq_t p);

//mpolx_t mpolz2x(const mpolz_t &p);
//upolx_t upolz2x(const upolz_t &p);

//mpolx_t mpolx_normalize(const mpolx_t &p);
//upolx_t upolx_normalize(const upolx_t &p);

//upolq_t upolz_normalize(const upolz_t &p);

#include "isolver.h"

mpoli_t mpolz2i(const mpolz_t &p);
upoli_t upolz2i(const upolz_t &p);


// corrected version
template<class R> inline void diff2(R & r, const R & p)
{
    int n, i;
    r.resize(n=degree(p));
    for(i = 1; i < n+1; ++i) 
        r[i-1] = typename R::coeff_t(p[i] * typename R::coeff_t(i));
}

template <class R> inline R diff2(const R & p)
{
    R r(p); 
    diff2(r, p);
    return r;
}


template<class P>
P mvcoeff(P p, int var, int deg)
{
    P res;
    for (typename P::iterator it = p.begin(); it != p.end(); it++) {
        typename P::monom_t m(*it);
        if (m[var] == deg) {
            if (deg > 0) m.set_expt(var, 0);
            res += m;
        }
    }
    return res;
}

upolz_t upolz_divby(const upolz_t &p, ZZ t);

template<class MP, class UP> MP upol2m(const UP& p, int i=1)
{
    MP q;
    for (int j = 0; j <= degree(p); j++)
	q += typename MP::monom_t(p[j], i, j);
    return q;
}

template<class UP, class MP> UP mpol2u(const MP& p, int i)
{
    UP q(degree(p)+1, AsSize());
    for (typename MP::const_iterator it = p.begin(); it != p.end(); it++)
	q[(*it)[i]] = it->coeff(); 
    return q;
}

template<class Kernel>
void print( const typename Kernel::AlgebraicRealSet_1 & s )
{
  typedef typename Kernel::AlgebraicRealSet_1 AlgebraicRealSet_1;
  double tmp;
  for ( typename AlgebraicRealSet_1::const_iterator it = s.begin(); 
	it != s.end(); 
	it++ )
    {
      Kernel::approx(tmp,*it);
      std::cout << tmp << ", ";
    };
  std::cout << std::endl;
};

template<class AK>
void printSol( const mmx::Seq< typename AK::AlgebraicReal_1 >& s, bool is_float = 
false)
{
   if (!is_float)
     {
       for (unsigned i = 0; i < s.size(); ++i )
        {
          std::cout << i << ": " << s[i] << std::endl;
        }
       return;
     }
   for (unsigned i = 0; i < s.size(); ++i )
     {
       std::cout << i << ": " << s[i].interval() << " " << to_double( 
s[i]) << std::endl;
       //std::cout << i << ": " << to_double( s[i]) << std::endl;
     }
   return;

}

/*
status:
-2 = cannot separate roots, possibly double root
-1 = uncertain discriminant sign ==> uncertain roots
0 = no real roots
1 = 1 double root
2 = 2 real roots
*/

template <class P> std::pair<typename P::coeff_t, typename P::coeff_t> TrinomialSolver(const P &p, int &status)
{
    typedef typename P::coeff_t T;
    
//    assert ( degree(p) == 2 );

    T disc = p[1]*p[1] - 4*p[2]*p[0];
    if (disc < 0) {
        status = 0;
        return std::pair<T,T>();
    }
    if (disc > 0) status = 2;
    else if (disc == 0) status = 1;
    else {
        status = -1;
#ifdef VERBOSE
        std::cerr << "WARNING: TrinomialSolver: discriminant contains zero\n";
#endif
    }
    
    T sqd = sqrt(disc);
//    std::cerr << "d, sqd = " << disc << ' ' << sqd << std::endl;
    
    T r1 = (-1*p[1] - sqd) / (2*p[2]);
    T r2 = (-1*p[1] + sqd) / (2*p[2]);

    if (r1 < r2) return std::pair<T,T>(r1,r2);
    else if (r1 > r2) return std::pair<T,T>(r2,r1);
    else if (r1 == r2) return std::pair<T,T>(r1,r2);
    else {
//        std::cerr << r1 << std::endl << r2 << std::endl;
//        T h = hull(r1, r2);
#ifdef VERBOSE
        std::cerr << "WARNING: TrinomialSolver: cannot separate roots -- possibly double root\n";
#endif
        status = -2;
        return std::pair<T,T>(r1,r2);
    }
}

template<class Tp> typename Tp::value_type cauchy_bound(const Tp &p)
{
    typedef typename Tp::value_type V_t;
    assert ( mmx::sign(lcoeff(p)) != 0 );
    int d = degree(p);
    if (d == 0) return abs(p[0]);
    V_t m = abs(p[d-1]);
    for (int i = d-2; i >= 0; i--) if (abs(p[i]) > m) m = abs(p[i]);
    m = m + abs(p[d]);
    return V_t(m) / V_t(abs(p[d]));
}

class PolyObject {
protected:
    upolz_t poly_;
    RootSeq sol;
    bool solved;

public:
    PolyObject(): solved(false) { }

    int size() const { return sol.size(); }

    const RootSeq& solve() {
        sol = AK::solve(poly_, Sturm<ZZ>());
        solved = true;
        /*std::cerr << poly_ << std::endl;
        std::cerr << "***** " << sol.size() << " **** solutions" << std::endl;
        std::cerr << sol << std::endl;*/
        return sol;
    }
    bool is_solved() const { return solved; }
    
    const upolz_t& poly() const { return poly_; }
    Root get_sol(int i) const { return sol[i]; }
};

upolz_t interpolate(int n, ZZ *x, ZZ *val);
extern template std::pair<IntF,IntF> TrinomialSolver<upoli_t>(const upoli_t &p, int &status);

#endif
