/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _EXCEPTION_H_
#define _EXCEPTION_H_

#include <string>

class Exception {
    int err;
    std::string msg;
public:
    enum { NOCONVERGE, BADSQRT, LOWPREC };

    Exception(int aerr = -1): err(aerr) { }
    Exception(int aerr, const std::string& amsg): err(aerr), msg(amsg) { }
    int get_err() const { return err; }
    const std::string& get_msg() const { return msg; }
};

#endif
