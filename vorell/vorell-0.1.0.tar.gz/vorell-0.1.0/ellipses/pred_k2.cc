/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "pred_k2.h"
#include "bitangent.h"

int distance_from_bitangent_wbtan(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict, 
                                  Bitangent &bt12, Bitangent &bt13)
{
    bt12.solve();
    // res = 1 if intersects bitangent, 0 if tangent (int/ext) to bitangent, -1 otherwise
    Root tanpoint = bt12.get_sol(bt12.get_external());
    int res = AK::sign_at(bt13.poly(), tanpoint);
    if (conflict != NULL) *conflict = res;
    if (res == 1) return -1;
    
    upolz_t tan11 = tan_poly_xy(ELLIPSE_PC(e1), e1.pc[3], e1.pc[4]); // TODO: tan11 already computed in bt12!
    upolz_t tan13 = tan_poly_xy(ELLIPSE_PC(e1), e3.pc[3], e3.pc[4]);
    int side = AK::sign_at(tan11, tanpoint) * AK::sign_at(tan13, tanpoint);
    // TODO: first sign (tan11) always positive?
    
    // now side can't be 0 ;-)    
    
    if (side > 0) return -res; // 1 or 0
    return -1;
}

int distance_from_bitangent(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict)
{
    Bitangent bt12(e1, e2);
    Bitangent bt13(e1, e3);
    
    return distance_from_bitangent_wbtan(e1, e2, e3, conflict, bt12, bt13);
}

int in_circle(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3)
{
    Bitangent bt21(e2, e1);
    Bitangent bt12(e1, e2);
    Bitangent bt23(e2, e3);
    
    int s = distance_from_bitangent_wbtan(e2, e1, e3, NULL, bt21, bt23);
    if (s != 0) return s;
    
    Root r = bt21.get_sol(bt21.get_external());
    Root t = bt12.get_sol(bt12.get_other_external());
    
    // old incorrect version
    //int o2 = e2.ccw(e3.get_xc(), e3.get_yc(), e2.get_xc(), e2.get_yc(), r);
    //int o1 = e1.ccw(e3.get_xc(), e3.get_yc(), e1.get_xc(), e1.get_yc(), t);
    
    // TODO: works only for non-inter. ellipses
    RangeF vr, vt;
    int v = visible_arc_generic(e2, INTERVAL(e3.get_xc()), INTERVAL(e3.get_yc()), vr);
    assert(v == 0);
    v = visible_arc_generic(e1, INTERVAL(e3.get_xc()), INTERVAL(e3.get_yc()), vt);
    assert(v == 0);
    bool inside = bt21.chrange().containsi(vr.a) && bt12.chrange().containsi(vt.a);

    if (inside) return -1;
    return 1;
}

int bounded_side_of_arc(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, const Ellipse &q, const bool first)
{
    Bitangent bt21(e2, e1);
    Bitangent bt23(e2, e3);
    Bitangent bt2q(e2, q);
    Root p;
    
    VORELL::Range<Root> arc(bt21.get_sol(bt21.get_other_external()), bt23.get_sol(bt23.get_external()));
//    std::cerr << arc << std::endl;
    if (first) p = bt2q.get_sol(bt2q.get_external());
    else p = bt2q.get_sol(bt2q.get_other_external());
    if (arc.touches(p)) return 0;
    if (arc.contains(p)) return 1;
    return -1;
}
