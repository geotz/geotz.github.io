/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _BISECTOR_TR_H_
#define _BISECTOR_TR_H_

#include "algebra.h"
#include "ellipse.h"

using namespace mmx;

mpolz_t ell_bisector(QQ a1, QQ b1, QQ w1, QQ xc1, QQ yc1, 
	    QQ a2, QQ b2, QQ w2, QQ xc2, QQ yc2, int var1, int var2);

upolz_t ell_bisector_CC_tt(QQ a1, QQ xc1, QQ yc1, QQ a2, QQ xc2, QQ yc2);

class Bisector {
    
    Ellipse e1_, e2_;
    int var1_, var2_;
    QQ cpoly[7][7];
    
    mpolz_t bpoly_;
    
    friend class BisectorX;
    
public:
    Bisector() { }
    Bisector(const Ellipse &e1, const Ellipse &e2, int var1 = 1, int var2 = 2);
    
    upolz_t poly(const ZZ t) {
        return mpol2u<upolz_t,mpolz_t>(subs(var1_, t, bpoly_), var2_);
    }

    upolz_t poly_CC_tt() {
        return ell_bisector_CC_tt(e1_.pc[0], e1_.pc[3], e1_.pc[4], e2_.pc[0], e2_.pc[3], e2_.pc[4]);
    }

    const mpolz_t& bpoly() { return bpoly_; }
    mpolz_t bpoly_xy() { return ell_bisector(ELLIPSE_PC(e1_), ELLIPSE_PC(e2_), 1, 2); }
};

#endif
