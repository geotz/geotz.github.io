/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"
#include "pred_k4.h"
#include "parnorm.h"

// res = -1 if zeta(vc2) smaller
int order_on_finite_bisector(const VoronoiCircle &vc1, const VoronoiCircle &vc2, const Ellipse &e1, const Ellipse &e2)
{
    ShortestDistance sd12(e1, e2);
    
    IntF t1x, t2x, px;
    Root t1, t2;
    bool exact = ! (vc1.permuted() || vc2.permuted() || vc1.with_subdivision() || vc2.with_subdivision());
    Root p = sd12.get_tsol();
    VORELL::Range<Root> trange = sd12.get_trange();
    // std::cerr << p << std::endl;

    int o1, o2;
    if (exact) {
        t1 = vc1.get_tsol();
        t2 = vc2.get_tsol();
/*        std::cerr << "e1 = " << e1 << std::endl;
        std::cerr << "e2 = " << e2 << std::endl;
        std::cerr << "t1 = " << t1 << std::endl;
        std::cerr << "t2 = " << t2 << std::endl;
        std::cerr << "p = " << p << std::endl;
        std::cerr << "p' = " << sd12.get_rsol() << std::endl;
        std::cerr << "trange = " << trange << std::endl;*/
        o1 = trange.order(t1, p);
        o2 = trange.order(t2, p);
    } else {
        std::cerr << "order inexact!\n";
        std::cerr << "t1x = " << t1x << std::endl;
        t1x = vc1.get_solx(0);
        std::cerr << "t1x = " << t1x << std::endl;
        t2x = vc2.get_solx(0);
        std::cerr << "t2x = " << t1x << std::endl;
        px = INTERVAL(p);
        std::cerr << "px = " << px << std::endl;
        std::cerr << "trange = " << trange << std::endl;
        o1 = trange.orderi(t1x, px);
        o2 = trange.orderi(t2x, px);
    }
    
    if ( o1 == 1 ) { 
      // left turn
      if ( o2 != 1 ) return -1;
      if (exact) return trange.order(t2, t1);
      return trange.orderi(t2x, t1x);

    } else if ( o1 == 0 ) { 
      // collinear
      if ( o2 == 0 ) return 0;
      return (o2 == 1) ? 1 : -1;
      
    } else {
      // right turn
      if ( o2 != -1 ) return 1;
      if (exact) return trange.order(t2, t1);
      return trange.orderi(t2x, t1x);
    }
}
