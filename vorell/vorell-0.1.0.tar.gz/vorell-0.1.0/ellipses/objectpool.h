/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _OBJECTPOOL_H_
#define _OBJECTPOOL_H_

#include <ext/hash_set>

template<class T>
class ObjectPool {

    struct hash_compare {
        bool operator()(const T &t1, const T &t2) const { return t1 == t2; }
    };

    struct hash_function {
        size_t operator()(const T &t) const { return t.hash(); }
    };

public:
    typedef __gnu_cxx::hash_set<T, hash_function, hash_compare> hash_set_t;

private:

    static hash_set_t pool;
    
public:    

    bool load(T& t) {
        typename hash_set_t::const_iterator it = pool.find(t);
        if (it != pool.end()) {
#ifdef VERBOSE
            std::cerr << "cache hit! [" << t.hash() << ']' << std::endl;
#endif
            t = *it;
            return true;
        }
        return false;
    }

    bool update(const T& t) {
        typename hash_set_t::const_iterator it = pool.find(t);
        if (it != pool.end()) {
#ifdef VERBOSE
            std::cerr << "cache update! [" << t.hash() << ']' << std::endl;
#endif
            pool.erase(*it);
            pool.insert(t);
            return true;
        }
        pool.insert(t);
        return false;
    }
};

template<class T> typename ObjectPool<T>::hash_set_t ObjectPool<T>::pool;

#endif
