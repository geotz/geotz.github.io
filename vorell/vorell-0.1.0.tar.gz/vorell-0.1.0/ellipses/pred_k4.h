/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _PRED_K4_H_
#define _PRED_K4_H_

#include "ellipse.h"
#include "incircle.h"

int order_on_finite_bisector(const VoronoiCircle &vc1, const VoronoiCircle &vc2, const Ellipse &e1, const Ellipse &e2);

#endif
