/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _INCIRCLE_EVAL_H_
#define _INCIRCLE_EVAL_H_

void ell_normal(QQ a, QQ b, QQ w, QQ xc, QQ yc, 
        upolq_t& poly_x, upolq_t& poly_y, upolq_t& poly_c);
        
mpolz_t ell_normals(QQ a1_, QQ b1_, QQ w1, QQ xc1, QQ xy1, 
		    QQ a2_, QQ b2_, QQ w2, QQ xc2, QQ xy2,
		    QQ a3_, QQ b3_, QQ w3, QQ xc3, QQ xy3);

upolz_t ell_resultant_CCC(QQ R1, QQ xc1, QQ yc1, QQ R2, QQ xc2, QQ yc2, QQ R3, QQ xc3, QQ yc3);

IntF eval_D(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
             const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
             IntF t, IntF r);
int sign_of_D(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
             const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
             IntF t, IntF r);

int sign_of_Q(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
                const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
                const IntF a3, const IntF b3, const IntF w3, const IntF xc3, const IntF yc3,
                const IntF t, const IntF r, const IntF s);

#endif
