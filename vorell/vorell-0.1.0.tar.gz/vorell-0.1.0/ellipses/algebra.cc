/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"

/*void seq_primpart(int len, QQ *p, ZZ *c)
{
    int i;
    ZZ tmp;
    
    int count = 0;
    for (i = 0; i < len; i++)
        count += denominator(p[i]) == denominator(p[i+1]);
    if (count == len-1) {
        for (i = 0; i < len; i++)
            c[i] = numerator(p[i]);
//        std::cerr << "primpart/UP: all denoms the same\n";
    } else {
        tmp = denominator(p[0]);
        for (i = 1; i < len; i++)
            tmp = lcm(tmp, denominator(p[i]));

        for (i = 0; i < len; i++)
            c[i] = (tmp / denominator(p[i])) * numerator(p[i]);
    }
    tmp = abs(c[0]);
    for (i = 1; i < len; i++) tmp = gcd(tmp, abs(c[i]));
    for (i = 0; i < len; i++) c[i] = numerator(c[i]) / tmp;
//    std::cerr << "primpart/UP: gcd = " << tmp << std::endl;
}*/

upolz_t primpart(const upolq_t p)
{
    int deg = degree(p);
    int i;
    ZZ c[deg+1], tmp;
    
    int count = 0;
    for (i = 0; i < deg; i++)
        count += denominator(p[i]) == denominator(p[i+1]);
    if (count == deg) {
        for (i = 0; i <= deg; i++)
            c[i] = numerator(p[i]);
//        std::cerr << "primpart/UP: all denoms the same\n";
    } else {
        tmp = denominator(p[0]);
        for (i = 1; i <= deg; i++)
            tmp = lcm(tmp, denominator(p[i]));

        for (i = 0; i <= deg; i++)
            c[i] = (tmp / denominator(p[i])) * numerator(p[i]);
    }
    tmp = abs(c[0]);
    for (i = 1; i <= deg; i++) tmp = gcd(tmp, abs(c[i]));
    for (i = 0; i <= deg; i++) c[i] = numerator(c[i]) / tmp;
//    std::cerr << "primpart/UP: gcd = " << tmp << std::endl;
    
    return upolz_t(deg + 1, c);
}

upolz_t primpart(const upolz_t p)
{
    int deg = degree(p);
    int i;
    ZZ c[deg+1], tmp;
    
//    std::cerr << deg << std::endl;
    for (i = 0; i <= deg; i++) c[i] = p[i];
    tmp = abs(c[0]);
    for (i = 1; i <= deg; i++) tmp = gcd(tmp, abs(c[i]));
    for (i = 0; i <= deg; i++) c[i] = c[i] / tmp;
//    std::cerr << "primpart/UP: gcd = " << tmp << std::endl;
    
    return upolz_t(deg + 1, c);
}

mpolz_t primpart(mpolq_t p)
{
    ZZ tmp;
    mpolz_t q;
    
    int count = 0;
    
    
    mpolq_t::iterator it = p.begin();
    if (it == p.end()) return mpolz_t();
    tmp = denominator(it->coeff());
    it++;
    for(; it!=p.end(); it++) {
        count += denominator(it->coeff()) == tmp;
    }
    if (count == p.size() - 1) {
        for (it = p.begin(); it != p.end(); it++)
            it->set_coeff(numerator(it->coeff()));
//        std::cerr << "primpart/MP: all denoms the same\n";
    } else {
	it = p.begin();
        tmp = denominator(it->coeff());
	it++;
        for (; it != p.end(); it++)
            tmp = lcm(tmp, denominator(it->coeff()));
//	std::cerr << "primpart/MP: lcm = " << tmp << std::endl;

        for (it=p.begin(); it != p.end(); it++)
            it->set_coeff( (tmp / denominator(it->coeff())) * numerator(it->coeff()) );
    }
    it = p.begin();
    tmp = numerator(abs(it->coeff()));
//    std::cerr << "primpart/MP: start from " << (*it) << endl;
    it++;
    for (; it != p.end(); it++) {
//	std::cerr << "primpart/MP: gcd (" << tmp << "," << it->coeff() << ")\n";
	tmp = gcd(tmp,  numerator(abs(it->coeff())));
//	std::cerr << "primpart/MP: cur_gcd = " << tmp << std::endl;
    }
    for (it = p.begin(); it != p.end(); it++) {
        it->set_coeff( numerator(it->coeff()) / tmp );
        monomz_t m = monomz_t(numerator(it->coeff()), it->size(), AsSize());
        for (int j = 1; j <= it->nvars(); j++) m.set_expt(j, (*it)[j]);
        q += m;
    }
//    std::cerr << "primpart/MP: gcd = " << tmp << std::endl;
    
    return q;
}


/*mpolx_t mpolx_normalize(const mpolx_t &p)
{
    mpolx_t x;
    double c = 0.0;
//    std::cerr << "original mpoly: " << p << std::endl;
    for (mpolx_t::const_iterator it = p.begin(); it != p.end(); it++) {
        if (abs(it->coeff()) > c) c = abs(it->coeff());
        x += *it;
    }
    for (mpolx_t::iterator it2 = x.begin(); it2 != x.end(); it2++) {
        it2->set_coeff(it2->coeff() / c);
    }
//    std::cerr << "normalized mpoly: " << x << std::endl;
    
    return x;
}


mpolx_t mpolz2x(const mpolz_t &p)
{
    mpolx_t x;
    for (mpolz_t::const_iterator it = p.begin(); it != p.end(); it++) {
        monomx_t m = monomx_t(to_double(it->coeff()), it->size(), AsSize());
        for (int j = 1; j <= it->nvars(); j++) m.set_expt(j, (*it)[j]);
        x += m;
    }
    
    return mpolx_normalize(x);
}*/

mpoli_t mpolz2i(const mpolz_t &p)
{
    mpoli_t x;
    for (mpolz_t::const_iterator it = p.begin(); it != p.end(); it++) {
        monomi_t m = monomi_t(INTERVAL(it->coeff()), it->size(), AsSize());
        for (int j = 1; j <= it->nvars(); j++) m.set_expt(j, (*it)[j]);
        x += m;
    }
    
    return x;
}

/*upolq_t upolz_normalize(const upolz_t &p)
{
    upolq_t x(degree(p) + 1, AsSize());
    ZZ c = 0;
    int i;
//    std::cerr << "original upoly: " << p << std::endl;
    for (i = 0; i <= degree(p); i++) {
        x[i] = p[i];
        if (abs(x[i]) > c) c = abs(x[i]);
    }
    for (i = 0; i <= degree(p); i++) {
        x[i] = x[i] / c;
    }
   
//    std::cerr << "normalized upoly: " << x << std::endl;
    return x;
}*/

/*upolx_t upolx_normalize(const upolx_t &p)
{
    upolx_t x(degree(p) + 1, AsSize());
    double c = 0.0;
    int i;
//    std::cerr << "original upoly: " << p << std::endl;
    for (i = 0; i <= degree(p); i++) {
        x[i] = p[i];
        if (abs(x[i]) > c) c = abs(x[i]);
    }
    for (i = 0; i <= degree(p); i++) {
        x[i] = x[i] / c;
    }
   
//    std::cerr << "normalized upoly: " << x << std::endl;
    return x;
}*/
        
/*upolx_t upolz2x(const upolz_t &p)
{
    upolx_t x(degree(p) + 1, AsSize());
    for (int i = 0; i <= degree(p); i++) x[i] = mmx::to_double(p[i]);
    return upolx_normalize(x);
}*/

upoli_t upolz2i(const upolz_t &p)
{
//    upolq_t pn = upolz_normalize(p);
    upoli_t x(degree(p) + 1, AsSize());
    for (int i = 0; i <= degree(p); i++) x[i] = INTERVAL(p[i]);
    return x;
}

upolz_t upolz_divby(const upolz_t &p, ZZ t)
{
    upolz_t q(degree(p) + 1, AsSize());
    for (int i = 0; i <= degree(p); i++) q[i] = p[i] / t;
    return q;
}


upolz_t eval_newton_poly(int n, ZZ *x, ZZ *b) 
{
    upolz_t p(n+1, AsSize());
    p = b[n];
    upolz_t tmp(2, AsSize());
    for (int i = n-1; i >=0; i--) {
        tmp[1] = 1;
        tmp[0] = -x[i];
        p = p * tmp + b[i];
    }
/*    upolz_t pz(degree(p)+1, AsSize());
    for (int i = 0; i <= degree(p); i++) {
        pz[i] = numerator(p[i]);
        assert(denominator(p[i]) == 1);
    }*/
    return p;
}
        
inline ZZ eval_newton(int n, ZZ *x, ZZ *b, ZZ z) 
{
    ZZ p = b[n];
    for (int i = n-1; i >=0; i--)
        p = p * (z - x[i]) + b[i];
//    assert(denominator(p) == 1);
    return p;
}

upolz_t interpolate(int n, ZZ *x, ZZ *val)
{
    ZZ b[n];
    int k, j;
    ZZ num, den;
    
    b[0] = val[0];
    for (k = 1; k < n; k++) {
        num = val[k] - eval_newton(k-1, x, b, x[k]);
        den = 1;
        for (j = 0; j < k; j++) den *= (x[k] - x[j]); // (k-j) if x's are sequential
        b[k] = num / den;
//        assert(denominator(b[k]) == 1);
    }
    return eval_newton_poly(n-1, x, b);
}

template std::pair<IntF,IntF> TrinomialSolver<upoli_t>(const upoli_t &p, int &status);
