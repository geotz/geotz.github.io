/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _PRED_K1_H_
#define _PRED_K1_H_

#include "ellipse.h"

int side_of_bisector(Ellipse e1, Ellipse e2, QQ v1, QQ v2);

#endif
