// Copyright 2007 Elias P. Tsigaridas

#include <realroot/kernel.hpp>
#include <NTL/ZZXFactoring.h>

#include "NTL_conversions.hpp"

#define ALLOC(p) (((long *) (p))[0])
#define SIZE(p) (((long *) (p))[1])
#define DATA(p) ((mp_limb_t *) (((long *) (p)) + 2))
#define MustAlloc(c, len)  (!(c) || (ALLOC(c) >> 2) < (len))

#define GET_SIZE_NEG(sz, neg, p)		\
  do						\
    {						\
      long _s;					\
      _s = SIZE(p);				\
      if (_s < 0) {				\
	sz = -_s;				\
	neg = 1;				\
      }						\
      else {					\
	sz = _s;				\
	neg = 0;				\
      }						\
    }						\
  while (0)

#define STRIP(sz, p)				\
  do						\
    {						\
      long _i;					\
      _i = sz - 1;				\
      while (_i >= 0 && p[_i] == 0) _i--;	\
      sz = _i + 1;				\
    }						\
  while (0)


namespace mmx 
{


  namespace meta 
  {
    
    void mpz2zz(mpz_t gnu, NTL::ZZ& ntl)
    {
      long size = gnu->_mp_size;
      //  bool neg=size<0?true:false;
      long asize=size<0?-size:size;
      if (size == 0) {_ntl_gzero(&(ntl.rep));return;}
      if (MustAlloc(ntl.rep, asize)) {_ntl_gsetlength(&(ntl.rep),asize);}
      //  mp_limb_t *ntl_limb = DATA(ntl.rep);
      memcpy(DATA(ntl.rep),gnu->_mp_d,sizeof(mp_limb_t)*asize);
      STRIP(asize,DATA(ntl.rep));
      SIZE(ntl.rep)=size;
    }
 
    void zz2mpz( NTL::ZZ& ntl, mpz_t gnu)
    {
      if ( ntl == 0) 
	{
	  mpz_set_ui(gnu, 0);
	  return;
	}
      
      long size = SIZE(ntl.rep);
      bool neg=size<0?true:false;
      long asize=size<0?-size:size;
      if (_ntl_giszero(ntl.rep)) { mpz_set_ui(gnu, 0);return;}
      if (asize > gnu->_mp_alloc) _mpz_realloc(gnu, asize);
      //mp_limb_t *ntl_limb = DATA(ntl.rep);
      memcpy(gnu->_mp_d,DATA(ntl.rep),sizeof(mp_limb_t)*asize);
      while (gnu->_mp_d[asize-1] == 0) asize--;
      gnu->_mp_size = neg?-asize:asize;
    }

    void upoldse2zzx( const upoldse<ZZ>& p, NTL::ZZX& f)
    {
      long d = degree( p);
      f.SetMaxLength( d+1);
      NTL::ZZ t;
      for (int i = 0; i <= d; ++i) 
	{
	  mpz2zz( p[i].get_mpz_t(), t);
	  NTL::SetCoeff( f, i, t);
	}
      return;
    }

    void zzx2upoldse( const NTL::ZZX& f, upoldse<ZZ>& p )
    {
      long d = NTL::deg( f);
      p.resize( d+1);
      NTL::ZZ t;
      for (int i = 0; i <= d; ++i) 
	{
	  t = NTL::coeff( f, i);
	  zz2mpz( t, p[i].get_mpz_t());
	}
      return;
    }
  } // namespace meta
  

  namespace FAST {
    
    Seq< std::pair< upoldse<ZZ>, long > >
    SquareFreeDecomposition( const upoldse<ZZ>& p, bool perform_factorization)
    {
  
      NTL::ZZX f;
      meta::upoldse2zzx( p, f);
      NTL::vec_pair_ZZX_long L;
      NTL::ZZ cont;

      if (perform_factorization) NTL::factor( cont, L, f);
      else NTL::SquareFreeDecomp( L, f);
  
      Seq< std::pair< upoldse<ZZ>, long > > s;

      upoldse<ZZ> P;
      for (int i = 0; i < L.length(); ++i) 
	{
	  meta::zzx2upoldse( L[i].a, P);
	  s.push_back( std::make_pair( P, L[i].b));
	}
      return s;
    }

    void  resultant( const upoldse<ZZ>& f,  const upoldse<ZZ>& g, ZZ& result)
    {
      NTL::ZZX a, b, s, t;
      NTL::ZZ r;
      meta::upoldse2zzx( f, a);
      meta::upoldse2zzx( g, b);
      
      NTL::XGCD( r, s, t, a, b, 0);
      meta::zz2mpz( r, result.get_mpz_t());
      return;
    }
    
    
    upoldse<ZZ>& 
    GCD(  const upoldse<ZZ>& a,  const upoldse<ZZ>& b, upoldse<ZZ>& c)
    {
      //  upoldse<ZZ> c;
      
      NTL::ZZX f, g, r;
      meta::upoldse2zzx( a, f);
      upoldse2zzx( b, g);
      NTL::GCD( r, f, g);
      meta::zzx2upoldse( r, c);
      return c;
      
    }
  } // namespace FAST
  

} //namespace mmx


  
#undef ALLOC
#undef SIZE
#undef DATA
#undef MustAlloc
#undef GET_SIZE_NEG
#undef STRIP


