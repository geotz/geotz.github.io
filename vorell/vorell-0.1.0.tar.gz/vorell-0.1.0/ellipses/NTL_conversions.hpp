// Copyright 2007 Elias P. Tsigaridas

#ifndef _MMX_NTL_CONVERSIONS_HPP_
#define _MMX_NTL_CONVERSIONS_HPP_

#include <realroot/kernel.hpp>
#include <NTL/ZZXFactoring.h>

namespace mmx 
{


  namespace meta 
  {
    
    void mpz2zz(mpz_t gnu, NTL::ZZ& ntl);
    
    void zz2mpz( NTL::ZZ& ntl, mpz_t gnu);
    
    void upoldse2zzx( const upoldse<ZZ>& p, NTL::ZZX& f);
    
    void zzx2upoldse( const NTL::ZZX& f, upoldse<ZZ>& p );
    

  } // namespace meta
  

  namespace FAST {
    
    Seq< std::pair< upoldse<ZZ>, long > >
    SquareFreeDecomposition( const upoldse<ZZ>& p, bool perform_factorization = false );
    
    void resultant( const upoldse<ZZ>& f,  const upoldse<ZZ>& g, ZZ& result);
    
    upoldse<ZZ>& 
    GCD(  const upoldse<ZZ>& a,  const upoldse<ZZ>& b, upoldse<ZZ>& c);
    
  } // namespace FAST
  

} //namespace mmx



#endif // _MMX_NTL_CONVERSIONS_HPP_
