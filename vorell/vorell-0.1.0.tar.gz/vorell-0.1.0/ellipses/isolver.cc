/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"

template IntF IntervalNewton<upoli_t>(const upoli_t &p, const upoli_t &dp, IntF approx);
template IntF IntervalBisect<upoli_t>(const upoli_t &p, IntF approx, int &status);
template IntF IntervalSolver<upoli_t>(const upoli_t &p, const upoli_t &dp, IntF approx, Float delta, int &status);

// taken from realroot by ET & AK
IntF INTERVAL(const Root &r)
{
  upoli_t f = upoli_t(r.size(), AsSize());
  for (int i = 0; i <= r.degree(); i++) {
      f[i] = INTERVAL(r[i]);
  }
  
  int d = r.degree();
  
/*  for (int i = 0; i < d; i++) {
      f[i] = f[i] / f[d];
  }
  f[d] = INTERVAL(1);*/

  if ( d == 1 ) {
    return - f[0] / f[1];
  }

  if ( d == 2 ) {    
    IntF D = sqrt(INTERVAL(r.discriminant()));

    assert(f[2] > 0);

    if ( ! r.which() )
      D = -D;

    return ( D - f[1] ) / ( f[2] * 2 );
  }

  IntF ap = INTERVAL(r.left(), r.right());
//  std::cerr << "APPROXIMATE IN " << ap << ap.width() << std::endl;
  int status;
  IntF appx_sol =  IntervalSolver(f, diff2(f), ap, 0, status);
  assert (status == 1);
  return ( appx_sol );
}

IntF mpol_eval(const mpoli_t p, const std::vector<IntF>& v)
{
  IntF r(0);
  for(mpoli_t::const_iterator it=p.begin(); it!=p.end(); ++it)
    {
      IntF c = it->coeff();
      for(unsigned i=0;i< it->size();++i)
	for(unsigned  k=0;k<(*it)[i];k++)
	  {
	    c = c * v[i];
	  }
      r = r + c;
    }
  return r;
}
