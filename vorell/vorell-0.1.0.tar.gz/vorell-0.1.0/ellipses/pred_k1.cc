/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "pred_k1.h"

QQ ell_eval_R(Ellipse e1, QQ x, QQ y)
{
    return e1.J2*(x*x+y*y) + 2*(e1.ac[0]*e1.ac[4]-e1.ac[1]*e1.ac[3])*y + 2*(e1.ac[2]*e1.ac[3]-e1.ac[1]*e1.ac[4])*x + 
           e1.J1*e1.ac[5] - e1.ac[3]*e1.ac[3] - e1.ac[4]*e1.ac[4];
}

// Delta[v1,v2](s), deg_s = 4
upolz_t ell_distance_poly(Ellipse e1, QQ v1, QQ v2)
{
    QQ p[5];
    QQ E = e1.eval_eq(v1, v2);
    QQ R = ell_eval_R(e1, v1, v2);
    QQ J1 = e1.J1;
    QQ J2 = e1.J2;
    QQ t2 = J2 * J2;
    QQ t6 = t2 * E;
    QQ t4 = J2 * E * J1;
    QQ t1 = E * E;
    QQ t3 = t6;
    QQ t5 = R * R;
    p[0] = t1 * (4 * t3 + t5);
    QQ t14 = t1 * t2;
    p[1] = 2 * (-6 * t14 - t5 * E) * J1 + 
           2 * (2 * t5 + 9 * t3 - t1 * J2) * R;
    QQ t27 = J1 * J1;
    QQ t34 = t2 * J1;
    p[2] = t14 - 27 * t2 * t2 + (-18 * t6 - 12 * t5) * J2 + 
           (4 * t4 - 18 * t34) * R + (12 * t3 + t5) * t27;
    p[3] = -2 * J2 * (-9 * t34 + t4 - 6 * J2 * R + 
           (2 * J2 * J1 + R) * t27);
    p[4] = -t2 * (-t27 + 4 * J2);
    
    upolq_t poly(5, p);
    return primpart(poly);
}

int side_of_bisector(Ellipse e1, Ellipse e2, QQ v1, QQ v2)
{
    upolz_t dpoly1 = ell_distance_poly(e1, v1, v2);
//    std::cerr << dpoly1 << std::endl;
    RootSeq sol1 = AK::solve( dpoly1, Sturm<ZZ>() );
//    std::cerr << sol1 << std::endl;
    RootSeq::const_iterator it1 = sol1.begin();
    while (*it1 < 0) it1++;
//    std::cerr << *it1 << std::endl;
    
    upolz_t dpoly2 = ell_distance_poly(e2, v1, v2);
//    std::cerr << dpoly2 << std::endl;
    RootSeq sol2 = AK::solve( dpoly2, Sturm<ZZ>() );
//    std::cerr << sol2 << std::endl;
    RootSeq::const_iterator it2 = sol2.begin();
    while (*it2 < 0) it2++;
//    std::cerr << *it2 << std::endl;
    
    return AK::compare(*it1, *it2);
}
