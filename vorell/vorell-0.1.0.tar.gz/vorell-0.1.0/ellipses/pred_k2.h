/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _PRED_K2_H_
#define _PRED_K2_H_

#include "ellipse.h"
#include "bitangent.h"

int distance_from_bitangent_wbtan(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict, 
                                  Bitangent &bt12, Bitangent &bt13);

int distance_from_bitangent(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict = NULL);

int in_circle(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3);

int bounded_side_of_arc(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, const Ellipse &q, const bool first);
        
#endif
