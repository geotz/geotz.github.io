/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _BISECTORX_H_
#define _BISECTORX_H_

#include "bisector_tr.h"
#include "objectpool.h"

IntF ellipse_x(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, const IntF t);
IntF ellipse_y(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, const IntF t);

// approximate bisector
class BisectorX: Bisector {
    
//    mpoli_t bpolyx_;
    upoli_t rcoeff[7];
    bool certified;
    int status;
    
    void init() {
        for (int i = 0; i < 7; i++) {
            rcoeff[i] = upoli_t(7, AsSize());
            for (int j = 0; j < 7; j++) rcoeff[i][j] = INTERVAL(cpoly[i][j]);
        }
    }
    
public:
    RangeF last_visible_arc;
    RangeF last_apollonius_arc;
        
    BisectorX() { }
    
    BisectorX(const Ellipse &e1, const Ellipse &e2, bool cert = true): 
            Bisector(e1, e2, 1, 2), certified(cert) { init(); }

    BisectorX(const Bisector &b, bool cert = true): Bisector(b), certified(cert) { init(); }
    
    const upoli_t polyx(const IntF t) {
        upoli_t pol(8, AsSize());
        for (int i = 0; i < 7; i++) pol[i] = rcoeff[i](t);
        return pol;
    }
    
//    const mpoli_t& bpolyx() { return bpolyx_; }
    
    IntF solve(const IntF t);
    
    //int get_status() const { return status; }
    
    void get_coords(const IntF t, IntF r, IntF& x, IntF& y, int& cstatus);
    void get_coords(const IntF t, IntF& x, IntF& y, int& cstatus);
    
    //get squared radius of bitangent circle
    void get_radius2(const IntF t, const IntF xc, const IntF yc, IntF &radius2);
};

class BisectorCurve {
    
    Ellipse e1_, e2_, e3_, e4_;
    BisectorX bx12;
    RangeF trange;
    int nell;
    
    static const int res;
    static const double near;
    static const double magnify;
    
    void add_point(Float p);

    void generate_points();

    ObjectPool<BisectorCurve> cache;

public:
    std::vector<double> xx, yy;

    bool operator==(const BisectorCurve &x) const;
    size_t hash() const;

    BisectorCurve() { }
    // bisector curve
    BisectorCurve(const Ellipse& e1, const Ellipse& e2);
    // bisector ray
    BisectorCurve(const Ellipse& e1, const Ellipse& e2, const Ellipse &e3);
    // bisector segment
    BisectorCurve(const Ellipse& e1, const Ellipse& e2, const Ellipse &e3, const Ellipse &e4);

};

int visible_arc_generic(const Ellipse e, IntF xe, IntF ye, RangeF &result);

#endif
