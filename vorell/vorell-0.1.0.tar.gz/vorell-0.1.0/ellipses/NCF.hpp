// Copyright 2007 Elias P. Tsigaridas

#ifndef _synaps_solve_slv_h_
#define _synaps_solve_slv_h_

#include <algebrix/Interval.hpp>
#include <algebrix/traits.hpp>
#include <algebrix/upoldse.hpp>
#include <realroot/solver_base.hpp>
#include <realroot/small_degree.h>
#include <realroot/sturm/common.h>
#include <realroot/sturm/solve_sturm.h>
//#include <realroot/sturm/solve_sturm_contfrac.h>
#include <algebrix/square_free.hpp>
#include <algebrix/bound.hpp>
#include <realroot/sturm/construct_root_of.h>

#include <subdivix/contfrac.hpp>
#include "NTL_conversions.hpp"

namespace mmx {


  template < class NT >
  struct NCF : public solver_base<NT>
  {
    typedef NCF          self_t;
  };


  namespace meta 
  {
    
    template < typename K,
	       typename OutputIterator > inline
    OutputIterator
    solve_slv( const typename K::Poly& h, OutputIterator sol, K)
       
    {
      typedef typename K::RT    RT;
      typedef typename K::FT    FT;
      typedef typename K::FIT   FIT;
      typedef typename K::RO_t  RO_t;
      typedef typename K::Poly  Poly;


      if (UPOLDSE::degree(h) < 5) {
	return solve_small_degree(h, 1, sol, K());
      }


      Seq< std::pair<Poly, long> > PL = FAST::SquareFreeDecomposition( h, true);
      //      Seq<Poly> PL = square_free_factorisation( f);

      for (unsigned i = 0; i < PL.size(); ++i) {
	if (UPOLDSE::degree( PL[i].first) < 5) {
	  solve_small_degree( PL[i].first, i+1, sol, K());
	} else {
	  Seq<FIT> intervals;
	  CF_solve( PL[i].first, std::back_inserter( intervals.rep()), 1, K());

	  //	    sturm_rootof( PL[i], i+1, sol, K());
	  if (intervals.size() == 0) continue;
	  for (unsigned j = 0; j < intervals.size(); ++j)  
	    {
	      RO_t r( ALGEBRAIC::construct_root_of( PL[i].first, intervals[j], K())); 
	      r.set_multiplicity( PL[i].second); 
	      *sol++ = r;
	    }
	}
      }	
      
      return sol; 
    }

    template < typename K,
	       typename OutputIterator > inline
    OutputIterator
    isolate_slv( const typename K::Poly& h, OutputIterator intervals, K)
       
    {
      typedef typename K::RT    RT;
      typedef typename K::FT    FT;
      typedef typename K::FIT   FIT;
      typedef typename K::RO_t  RO_t;
      typedef typename K::Poly  Poly;


      if (UPOLDSE::degree(h) < 5) {
	Seq<RO_t> r;
	solve_small_degree(h, 1, std::back_inserter( r.rep()), K());
	for (unsigned i = 0; i < r.size(); ++i)
	  *intervals++ = r[i].interval();
	return intervals;
      }


      Seq< std::pair<Poly, long> > PL = FAST::SquareFreeDecomposition( h, true);
      //      Seq<Poly> PL = square_free_factorisation( f);

      for (unsigned i = 0; i < PL.size(); ++i) 
	{
	  if (UPOLDSE::degree( PL[i].first) < 5) 
	    {
	      Seq<RO_t> r;
	      solve_small_degree( PL[i].first, i+1, std::back_inserter( r.rep()), K());
	      for (unsigned i = 0; i < r.size(); ++i)
		*intervals++ = r[i].interval();
	    } else {
	    CF_solve( PL[i].first, intervals, 1, K());
	  }
	}      
      return intervals; 
    }
  
  } //namespace meta 


  template < class NT > inline
  Seq< typename NCF<NT>::RO_t > 
  actual_solve( const typename NCF<NT>::Poly& f, NCF<NT>)
  {
    typedef NCF<NT>             K;
    typedef typename K::RO_t      RO_t;
    
    Seq<RO_t> sol;
    meta::solve_slv(f, std::back_inserter(sol.rep()), K());
    std::stable_sort( sol.begin(), sol.end(), ALGEBRAIC::Refine_compare());
    return sol;
  }
   
  template < class NT > inline
  Seq< typename NCF<NT>::FIT >
  actual_isolate( const typename NCF<NT>::Poly& f, NCF<NT>)
  {
    typedef NCF<NT>             K;
    typedef typename K::FIT     FIT;
    
    Seq<FIT> sol;
    meta::isolate_slv(f, std::back_inserter(sol.rep()), K());
    return sol;
  }

} //namespace mmx

#endif // _SYNAPS_SOLVE_slv_H_


