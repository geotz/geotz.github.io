/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _RANGE_H_
#define _RANGE_H_

namespace VORELL {

template<class T>
class Range {
private:
    bool empty;
public:
    T a, b;

    Range() { empty = true; }
    Range(const T &a_, const T &b_): empty(false), a(a_), b(b_) { }
//    Range(const IntF a_): empty(false), a(a_.lower()), b(a_.upper()) { }
        
    bool is_empty() const { return empty; }
    void mkempty() { empty = true; }
    bool is_finite() const { return empty || a <= b; }
    bool is_infinite() const { return !is_finite(); }
    bool is_exact() const { return empty || a == b; }

    T midpoint() const { 
        if (is_finite()) {
            T m = a + (b - a) / T(2);
            assert (m >= a && m <= b);
            return m;
        } else { // via symmetric ;-) !
            T pa, pb, pm;
            if ((a > 0 && b > 0) || (a < 0 && b < 0)) {
                pa = b; pb = a;
            } else {
                pa = T(-1)/a;
                pb = T(-1)/b;
            }
            pm = pa + (pb - pa) / T(2);
            assert (pm > 0 || pm < 0);
//            std::cerr << "projective : " << pa << ' ' << pm << ' ' << pb << std::endl;
            T m = T(-1)/pm;
            assert (m >= a || m <= b);
            return m;
        }
//        return (m > b)? b: m;
    }

    T width() const { 
        assert (is_finite());
        return (b - a);
     }
    
    friend std::ostream& operator<<(std::ostream& i, const Range<T>& r) {
        if (r.empty) return (i << "[ ]");
        else return (i << '[' << r.a << ',' << r.b << ']');
    }

    IntF interval() const {
//        assert(is_finite());
        return IntF(a, b);
    }

    Range complement() const { return Range<T>(b, a); }
    
    Range hull(const Range<T> &r) const {
        if (is_finite() && r.is_finite()) {
            return Range(std::min(a,r.a), std::max(b,r.b));
        } else {
            std::cerr << "coverage of infinite ranges not supported!\n";
            abort();
        }
    }
    bool contains(const T q) const {
        if (empty) return false;
        if (is_finite())
            return (q >= a && q <= b);
        else return (q >= a || q <= b);
    }

/*    bool containsx(const double q) const {
        if (empty) return false;
        if (is_finite())
            return (q >= to_double(a) && q <= to_double(b));
        else return (q >= to_double(a) || q <= to_double(b));
    }*/
    
    bool containsi(const IntF q) const {
        if (empty) return false;
        if (is_finite())
            return (q >= INTERVAL(a) && q <= INTERVAL(b));
        else return (q >= INTERVAL(a) || q <= INTERVAL(b));
    }
    
    bool touches(const T q) const {
        if (empty) return false;
        return q == a || q == b;
    }
    
    int order(const T x1, const T x2) {
        assert (contains(x1) && contains(x2));
        if (is_finite()) {
            if (x1 < x2) return -1;
            if (x1 > x2) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
        if (x2 <= b) {
            if (x1 < x2) return -1;
            if (x1 > x2 && x1 <= b) return 1;
            if (x1 > x2 && x1 >= a) return -1;
            if (x1 == x2) return 0;
            assert (false);
        } else {
            if (x1 > x2) return 1;
            if (x1 < x2 && x1 >= a) return -1;
            if (x1 < x2 && x1 <= b) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
    }

/*    int orderx(double x1, double x2) {
        assert (containsx(x1) && containsx(x2));
        if (is_finite()) {
            if (x1 < x2) return -1;
            if (x1 > x2) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
        if (x2 <= b) {
            if (x1 < x2) return -1;
            if (x1 > x2 && x1 <= b) return 1;
            if (x1 > x2 && x1 >= a) return -1;
            if (x1 == x2) return 0;
            assert (false);
        } else {
            if (x1 > x2) return 1;
            if (x1 < x2 && x1 >= a) return -1;
            if (x1 < x2 && x1 <= b) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
    }*/
        
    int orderi(IntF x1, IntF x2) {
        assert (containsi(x1) && containsi(x2));
        if (is_finite()) {
            if (x1 < x2) return -1;
            if (x1 > x2) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
        if (x2 <= INTERVAL(b)) {
            if (x1 < x2) return -1;
            if (x1 > x2 && x1 <= INTERVAL(b)) return 1;
            if (x1 > x2 && x1 >= INTERVAL(a)) return -1;
            if (x1 == x2) return 0;
            assert (false);
        } else {
            if (x1 > x2) return 1;
            if (x1 < x2 && x1 >= INTERVAL(a)) return -1;
            if (x1 < x2 && x1 <= INTERVAL(b)) return 1;
            if (x1 == x2) return 0;
            assert (false);
        }
    }
    
    
    /*********************************************
     compute the intersection of two ranges
     there should be at most 1 infinite range
     the result is a range (should be a list of finite ranges)
     *********************************************/
    Range intersection(const Range &r) {
        if (is_finite()) {
            if (r.is_finite()) {
                T c1 = std::max(a,r.a); 
                T c2 = std::min(b,r.b);
                if (c1 > c2) return Range();
                else return Range(c1,c2);
            } else {
                T c1 = std::max(a,r.a); 
                T c2 = b;
                Range r1;
                if (c1 <= c2) r1 = Range(c1,c2);
                c2 = std::min(b,r.b); c1 = a;
                Range r2;
                if (c1 <= c2) r2 = Range(c1,c2);
                if (r1.is_empty()) {
                        if (r2.is_empty()) return Range();
                        else return r2;
                } else {
                        if (r2.is_empty()) return r1;
                        else {
#ifdef VERBOSE
                            std::cerr << "intersection splits range\n";
                            std::cerr << r1 << " AND " << r2 << std::endl;
#endif
                            // the intersection of two ranges should contain the left endpoint of the second
                            if (r1.touches(r.a)) return r1; // since r is infinite!
                            else return r2;
                        }
                }
            }
        } else {
            if (r.is_finite()) {
                T c1 = std::max(r.a,a); 
                T c2 = r.b;
                Range r1;
                if (c1<=c2) r1 = Range(c1,c2);
                c2 = std::min(r.b,b); c1 = r.a;
                Range r2;
                if (c1<=c2) r2 = Range(c1,c2);
                if (r1.is_empty()) {
                        if (r2.is_empty()) return Range();
                        else return r2;
                } else {
                        if (r2.is_empty()) return r1;
                        else { 
#ifdef VERBOSE
                            std::cerr << "intersection splits range\n";
                            std::cerr << r1 << " AND " << r2 << std::endl;
#endif
                            if (r1.touches(r.a)) return r1;
                            else return r2;
                        }
                }
            } else {
                Range c(complement());
                Range cr(r.complement());
                Range rf, ri;
                if (c.intersection(cr).is_empty()) { // finite part
                    if (cr.b < c.a) rf = Range(cr.b, c.a);
                    else rf = Range(c.b, cr.a);
                }
                // infinite part
                T c1 = std::max(a,r.a); 
                T c2 = std::min(b,r.b);
                ri = Range(c1,c2);
#ifdef VERBOSE
                if (!rf.is_empty()) {
                    std::cerr << "intersection splits range\n";
                    std::cerr << rf << " AND " << ri << std::endl;
                }
#endif
                if (rf.touches(r.a)) return rf;
                else return ri;
            }
        }
    }
};

} // namespace

#endif
