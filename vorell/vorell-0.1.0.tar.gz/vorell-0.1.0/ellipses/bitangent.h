/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _BITANGENT_H_
#define _BITANGENT_H_

#include "ellipse.h"

// deg(P) = 2, replaces x & y in the eq. of the tangent line and yields
// a polynomial in t; P stands for all tangent lines passing through (x,y)
// obviously, if (x,y) is inside the same ellipse, P has no solutions ;-)
upolz_t tan_poly_xy(const QQ a, const QQ b, const QQ w, const QQ xc, const QQ yc, 
                    const QQ x, const QQ y);
upoli_t tan_poly_xy(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, 
                    const IntF x, const IntF y);

upoli_t tan_poly_cut(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
        const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2, const IntF t);

int tan_poly_sign(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, 
        const IntF x, const IntF y, const IntF t);

upolz_t btan_poly(const QQ ai, const QQ bi, const QQ wi, const QQ xci, const QQ yci,
                 const QQ aj, const QQ bj, const QQ wj, const QQ xcj, const QQ ycj);

class Bitangent: public PolyObject {
    Ellipse e1_, e2_;
    int ext_;

public:
    Bitangent() { }
    Bitangent(const Ellipse &e1, const Ellipse &e2): e1_(e1), e2_(e2) {
        poly_ = btan_poly(ELLIPSE_PC(e1_), ELLIPSE_PC(e2_));
        ext_ = -1;
    }
    
    // returns an index to the external bitangent line that leaves both ellipses on
    // the left side; the other 3 bitangents follow in cyclic order ccw: int, int, ext
    int get_external();

    // returns an index to the external bitangent line that leaves both ellipses on
    // the right side; the other 3 bitangents follow in cyclic order cw: int, int, ext
    int get_other_external() { return (get_external() + 3) % 4; }
    
    VORELL::Range<Root> chrange() { return VORELL::Range<Root>(get_sol(get_external()), get_sol(get_other_external())); }

    bool is_between(Root t);
//    bool is_between(double t);
    
    void approx_tan_point(IntF &x, IntF &y);
};

VORELL::Range<Root> visible_range(Bitangent &bt12, Bitangent &bt13);

#endif
