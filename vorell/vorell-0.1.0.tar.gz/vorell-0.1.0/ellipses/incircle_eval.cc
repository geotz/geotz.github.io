/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"

void ell_normal(QQ a, QQ b, QQ w, QQ xc, QQ yc, 
        upolq_t& poly_x, upolq_t& poly_y, upolq_t& poly_c)
{
    QQ t17, t16, t15, t5, t14, t9, t13, t12, t11, t4, t2;
    
    t17 = a*w;
    t16 = (w+1)*(w-1);
    t15 = b*w;
    t5 = a*xc;
    t14 = t5+2*yc*t17;
    t9 = w*w;
    t13 = b*(yc*t9+2*w*xc-yc);
    t12 = a*a-b*b;
    t11 = b*t16;
    t4 = -8*t17;
    t2 = 4*a*t16;
    
    poly_x.resize(5);
    poly_x[0] = -4*t15;
    poly_x[1] = t2;
    poly_x[2] = 0;
    poly_x[3] = t2;
    poly_x[4] = 4*t15;
    
    poly_y.resize(5);
    poly_y[0] = -2*t11;
    poly_y[1] = t4;
    poly_y[2] = 0;
    poly_y[3] = t4;
    poly_y[4] = 2*t11;
    
    poly_c.resize(5);
    poly_c[0] = 2*t13;
    poly_c[1] = 4*(-t5+t12)*t9+4*t12+4*t14;
    poly_c[2] = 0;
    poly_c[3] = 4*(-t5-t12)*t9-4*t12+4*t14;
    poly_c[4] = -2*t13;
}

mpolz_t ell_normals(QQ a1_, QQ b1_, QQ w1, QQ xc1, QQ xy1, 
		    QQ a2_, QQ b2_, QQ w2, QQ xc2, QQ xy2,
		    QQ a3_, QQ b3_, QQ w3, QQ xc3, QQ xy3)
{
    upolq_t a1, b1, c1, a2, b2, c2, a3, b3, c3;
    
    ell_normal(a1_, b1_, w1, xc1, xy1, a1, b1, c1);
    ell_normal(a2_, b2_, w2, xc2, xy2, a2, b2, c2);
    ell_normal(a3_, b3_, w3, xc3, xy3, a3, b3, c3);
    
    mpolq_t a1t, b1t, c1t;
    mpolq_t a2r, b2r, c2r;
    mpolq_t a3s, b3s, c3s;
    
    a1t = upol2m<mpolq_t,upolq_t>(a1,1);
    b1t = upol2m<mpolq_t,upolq_t>(b1,1);
    c1t = upol2m<mpolq_t,upolq_t>(c1,1);
    
    a2r = upol2m<mpolq_t,upolq_t>(a2,2);
    b2r = upol2m<mpolq_t,upolq_t>(b2,2);
    c2r = upol2m<mpolq_t,upolq_t>(c2,2);
    
    a3s = upol2m<mpolq_t,upolq_t>(a3,3);
    b3s = upol2m<mpolq_t,upolq_t>(b3,3);
    c3s = upol2m<mpolq_t,upolq_t>(c3,3);

    // determinant ;-)
    mpolq_t Q = a1t*b2r*c3s - a1t*c2r*b3s + b1t*c2r*a3s - b1t*a2r*c3s + c1t*a2r*b3s - c1t*b2r*a3s;
    return primpart(Q);
}

upolz_t ell_resultant_CCC(QQ R1, QQ xc1, QQ yc1, QQ R2, QQ xc2, QQ yc2, QQ R3, QQ xc3, QQ yc3)
{
    QQ t34, t35, t59, t48, t37, t55, t28, t49, t40, t51, 
            t26, t31, t32, t20, t23, t43, t58, t56, t47, 
            t44, t39, t38, t27;
    upolz_t poly(3, AsSize());
    
    t34 = -R3*R3+yc3*yc3+xc3*xc3;
    t35 = R2*R2-xc2*xc2-yc2*yc2;
    t59 = t34+t35;
    t48 = yc1*yc3;
    t37 = -2*t48;
    t55 = 2*R1;
    t28 = (-R2+R3)*t55+t59;
    t49 = yc1*yc2;
    t40 = 2*t49;
    t51 = -2*R1;
    t26 = R1*R1;
    t31 = t26+R3*t51-t34;
    t32 = -t26+R2*t55-t35;
    t20 = yc1*yc1;
    t23 = xc1*xc1;
    t43 = t23-t20;
    t58 = (-2*(yc2-yc3)*yc1-t28)*xc1+(t40-t32+t43)*xc3+(t37-t31-t43)*xc2;
    t56 = t20+t23+t26;
    t47 = xc3*xc1;
    t44 = xc1*xc2;
    t39 = -2*t44;
    t38 = 2*t47;
    t27 = t44*t55+t47*t51+(2*t48+t38-t56-t34)*R2+(t40+t37+t59)*R1+(-2*t49+t39+t56-t35)*R3;
    poly[0] = t27-t58;
    poly[1] = 2*(t38+t31-t43)*yc2+2*(t39+t32+t43)*yc3+2*(2*(xc2-xc3)* xc1+t28)*yc1;
    poly[2] = t27+t58;
   
    return primpart(poly);
}

/*ZZ calc_res_qb_ts(upolz_t Q, upolz_t B)
{
    return res_qb(Q[4], Q[3], Q[1], Q[0], B[6], B[5], B[4], B[3], B[2], B[1], B[0]);
}*/

IntF eval_D(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
             const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
             IntF t, IntF r)
{
    IntF t9, t7, t1, t2, t5, v, v1, v2, v3;

    t9 = (-IntF(r*r)+1)*b2;
    t7 = a2*r;
    t1 = w2*w2;
    t2 = w1*w1;
    t5 = -1+t2-t1*t2+t1-4*w1*w2;
    
    v1 = ((-4+4*t2)*w2+(-4*t1+4)*w1)*t7-t5*t9;
    v2 = 2*v1*t*a1;
    v3 = t5*t7-(w1*t1+w2-w1-w2*t2)*t9;
    v = v2 + 2*v3*b1*(-IntF(t*t)+1);
    
    return v;
}

int sign_of_D(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
             const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
             IntF t, IntF r)
{
    IntF d = eval_D(a1, b1, w1, xc1, yc1, a2, b2, w2, xc2, yc2, t, r);
#ifdef VERBOSE
    std::cerr << "dval = " << d << std::endl;
#endif
    return Sign(d);
}

IntF eval_Q(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
                const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
                const IntF a3, const IntF b3, const IntF w3, const IntF xc3, const IntF yc3,
                const IntF t, const IntF r, const IntF s)
{
IntF t16, t15, t359, t407, t7, t9, t268, t197, t275, t215,
      t245, t201, t276, t203, t292, t109, t206, t272, t4,
      t343, t96, t227, t219, t250, t251, t120, t22, t395,
      t199, t303, t112, t216, t258, t123, t77, t226, t14,
      t393, t380, t188, t13, t210, t374, t260, t60, t220,
      t222, t248, t246, t228, t214, t256, t116, t224, t225,
      t205, t249, t128, t105, t342, t373, t405, t247, t122,
      t237, t324, t213, t236, t372, t204, t277, t406, t355,
      t19, t10, t401, t263, t266, t381, t254, t240, t304,
      t190, t229, t403, t223, t273, t357, t126, t104, t106,
      t121, t66, t291, t113, t99, t62, poly;

      t16 = t*t;
      t15 = t16*t16;
      t359 = t15-1;
      t407 = b1*t359;
      t7 = w3*w3;
      t9 = w1*w1;
      t268 = -t9+1;
      t197 = yc1-yc2;
      t275 = 4*t197;
      t215 = 4-4*t9;
      t245 = t215*yc3;
      t201 = -yc3+yc1;
      t276 = 4*t201;
      t203 = xc3-xc1;
      t292 = t268*t197;
      t109 = 2*t203*w1+t292;
      t206 = xc1-xc2;
      t272 = 8*t206;
      t4 = w2*w2;
      t343 = -t4+1;
      t96 = t343*t292;
      t227 = -2*t9;
      t219 = t227+2;
      t250 = t219*xc3;
      t251 = t219*xc2;
      t120 = t251-t250;
      t22 = s*s;
      t395 = b3*IntF(t22*t22-INTERVAL(1));
      t199 = yc3-yc2;
      t303 = 2*t206;
      t112 = w2*t303-t343*t199;
      t216 = -2*t4+2;
      t258 = t216*xc3;
      t123 = -t216*xc1+t258;
      t77 = t123*w3-t112*t7+t112;
      t226 = -8*w3;
      t14 = t*t16;
      t393 = (t14-t)*(-a1*a1+b1*b1);
      t380 = (t9+1)*(-t216*t7-w2*t226+t216)*t393;
      t188 = 16*w3;
      t13 = s*t22;
      t210 = s-t13;
      t374 = -a3*a3+b3*b3;
      t260 = t210*t4;
      t60 = t374*(t210*w2*t219+(2*t260-2*t210)*w1);
      t220 = 4-4*t4;
      t222 = -8*xc3;
      t248 = t220*yc3;
      t246 = t215*yc1;
      t228 = 8*t9;
      t214 = -8+t228;
      t256 = t214*xc1;
      t116 = -t214*xc2+t256;
      t224 = -4*yc2;
      t225 = 4*yc1;
      t205 = t224+t225;
      t249 = t219*xc1;
      t128 = t249-t250;
      t105 = w1*t275+t128;
      t342 = -t7+1;
      t373 = t343*w3;
      t405 = t393*(t373-t342*w2);
      t247 = t215*yc2;
      t122 = -t247+t245;
      t237 = (t14+t)*a1;
      t324 = 8*xc2;
      t213 = t13+s;
      t236 = t213*a3;
      t372 = (t7+1)*t374*t210*(-t219*t4+8*w1*w2+t219);
      t204 = -xc2+xc3;
      t277 = 8*t204;
      t406 = IntF(IntF(t77*w1+t96*w3-t268*(2*t204*w3-t201*t7+t201)*w2)*t395-IntF(IntF(-t120*
w2+t109*t4-t109)*t7+t96-IntF(-IntF(-t220*yc2-w2*t272+t248)*w3-t123)*w1+(-IntF(-t246+t245)*
w3+t120)*w2)*t236- t60*t7-  t60)*IntF(t407);
      t406 = t406 - IntF(IntF(-IntF(IntF(-t4*t275+t205)*w3-
              (w3*t277-t7*t276+t225
-4*yc3)*w2)*w1-t77*t9+t77)*t395+t372-IntF(-IntF(t122*w3+t105*t7-t105)*t4-IntF(-t116*w2-
t122)*w3+t128*t7-IntF(IntF(t7*t277+t201*t188+t324+t222)*w2-t7*t275+t205)*w1-t128)*t236)
*t237-t380*t236-IntF(-2+t227)*t395*t405;
      
      t355 = t342*w1;
      t19 = r*r;
      t10 = r*t19;
      t401 = t10-r;
      t263 = t214*s;
      t266 = -t4-1;
      t381 = t401*(-t219*t7-w1*t226+t219)*t266;
      t254 = t214*t13;
      t240 = w3*t266;
      t304 = -8*t13;
      t190 = 8*t4;
      t229 = 8*s;
      t403 = (t401*(-t266*(-2*t15+2)*t355-t359*t219*t240)*t395+t359*t381*
t236)*b1-(-t401*((-t213*t190+t304-t229)*t355+(t254+t263)*t240)*a3+t381*t395)*
t237;
      t223 = 8*xc1;
      t273 = 8*t203;
      t357 = (-t7*t273+t199*t188-t223-t222)*w2;
      t126 = -t251+t249;
      t104 = -w1*t276-t126;
      t106 = -t216*xc2+w2*t275+t258;
      t121 = -t220*yc1+t248;
      t66 = -t121*w3+t106*t7-t106;
      t291 = t268*t201;
      t113 = w1*t303-t291;
      t99 = -16*t197*w2+t204*(-8+t190);
      t62 = t374*((-t254+t263)*w2-(8*t260-t229-t304)*w1);
      poly = IntF(IntF(t10+r)*IntF(IntF(t62*t7+IntF(-IntF(t122*w2+t104*t4-t104)*t7+IntF(-IntF(t256-t214*xc3)*w3
+t122)*w2-IntF(t99*w3+t121)*w1+t343*t126)*t395+t62+IntF(-t116*t373+t268*t357+IntF(-t99*t7+
t99-t201*w3*IntF(-16+16*t4))*w1)*t236)*t237+IntF(IntF(-IntF(-t120*w3+t113*t7-t113)*t4-IntF(IntF(-
t246+t247)*w2+t120)*w3+t342*t291+IntF(-IntF(-w3*t273-4*t199*t7+t224+4*yc3)*w2-t342*
t303)*w1)*t395-IntF(-IntF(IntF(t4*t272+t324-t223)*w3-t357)*w1+t66*t9-t66)*t236+t372)*t407+
t380*t395+IntF(8+t228)*t236*t405)+t403*a2)*a2+IntF(t406*t19*t19-t403*b2-t406)*b2;

    return poly;
}


int sign_of_Q(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
                const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2,
                const IntF a3, const IntF b3, const IntF w3, const IntF xc3, const IntF yc3,
                const IntF t, const IntF r, const IntF s)
{
    IntF q = eval_Q(a1, b1, w1, xc1, yc1, a2, b2, w2, xc2, yc2, a3, b3, w3, xc3, yc3, t, r, s);
#ifdef VERBOSE
    std::cerr << "qval = " << q << std::endl;
#endif
    return isign(q);
}
    

/*int sign_of_Q(mpolz_t &Q, IntF t, IntF r, IntF s)
{
    mpoli_t Qx = mpolz2i(Q);
    std::vector<IntF> V(3);
    V.push_back(t);
    V.push_back(r);
    V.push_back(s);
//    mpoli_t Qr = subs(1, t, Qx);
//    upoli_t Qs = mpol2u<upoli_t,mpoli_t>(subs(2, r, Qr), 3);
    IntF q = mpol_eval(Qx, V);
#ifdef VERBOSE
    std::cerr << "qval = " << q << std::endl;
#endif
    return Sign(q);
}*/
