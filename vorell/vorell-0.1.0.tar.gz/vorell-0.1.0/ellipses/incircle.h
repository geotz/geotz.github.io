/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _INCIRCLE_H_
#define _INCIRCLE_H_

#include "ellipse.h"
#include "algebra.h"
#include "bitangent.h"
#include "bisectorx.h"
#include "bisector_tr.h"

//struct ResHashEntry;

#ifndef NOHASH

#include "objectpool.h"

#endif

class EllipseTriplet;

class VoronoiCircle {

    int index[3];
    IntF solx[3];
    Root tsol;
    bool subdivision;
    
    int iters;
    BisectorX bx12, bx23, bx31;
    
    RangeF trange, rrange, srange;
    RangeF ch13_, ch32_, ch21_;
    
    friend class EllipseTriplet;
    friend std::ostream& operator<<(std::ostream& o, const VoronoiCircle& v);
    
    int  refine_t();
    void refine_rs();
    void info_t();
    void info_all();
    
    void approx_with_subdivision(EllipseTriplet &t123);
    void approx_with_resultant(EllipseTriplet &t123);

public:
    VoronoiCircle() { }
    VoronoiCircle(EllipseTriplet &t123);
    
    Root get_tsol() const { assert(! permuted() ); return tsol; }
    IntF get_solx(int i) const { 
        if (index[0] == i) return solx[0]; 
        if (index[1] == i) return solx[1];
        if (index[2] == i) return solx[2];
        assert(false);
    }
    bool permuted() const { return index[0] != 0; }
    bool with_subdivision() const { return subdivision; }
    
    void get_center(IntF &x, IntF &y, int &status) {
        bx12.get_coords(solx[0], solx[1], x, y, status);
    }

    void get_center_radius2(IntF &x, IntF &y, IntF &radius2, int &status) {
        bx12.get_coords(solx[0], solx[1], x, y, status);
        bx12.get_radius2(solx[0], x, y, radius2);
    }
};

class EllipseTriplet {

#ifndef NOHASH
    ObjectPool<EllipseTriplet> cache;
#endif
    
    Ellipse e1_, e2_, e3_;
    int ncircles;
    int index[3];
    mpolz_t Q;
    
    bool bisectors_computed;
    Bisector b12_, b13_;
    void compute_bisectors();

    bool parnormals_computed;
    upolz_t p12_, p13_;
    void compute_parnormals();
    
    bool resultant_computed;
    upolz_t respoly;
    void compute_resultant_EEE();
    void compute_resultant_CEE();
    void compute_resultant_CCE();
    void compute_resultant_CCC();
    void compute_resultant();

    bool bitangents_computed;
    Bitangent bt12_, bt21_, bt13_, bt31_, bt23_, bt32_;
    void compute_bitangents();
    
    int num_voronoi_circles;
    int count_voronoi_circles();

    bool ranges_computed;
    VORELL::Range<Root> trange, rrange, srange;
    void compute_ranges();
            
    friend class VoronoiCircle;
    VoronoiCircle vc;
    bool vc_computed;
    void compute_voronoi_circle();

//    friend int in_circle(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, const Ellipse &e4);
    int in_circle_with_subdivision(const Ellipse &e4);
        
public:
//    EllipseTriplet() { }
    EllipseTriplet(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, bool fixed_order = false);
    
    bool operator==(const EllipseTriplet &x) const {
        return e1_ == x.e1_ && e2_ == x.e2_ && e3_ == x.e3_ &&
                index[0] == x.index[0] && index[1] == x.index[1] && index[2] == x.index[2];
    }

    size_t hash() const {
        return (e1_.hash() + e2_.hash() + e3_.hash()) % ELL_HASH_PRIME;
    }
    
    int get_num_voronoi_circles();

    const VoronoiCircle& voronoi_circle() {
        compute_voronoi_circle();
        return vc;
    }

    upolz_t resultant() {
        compute_resultant();
        return respoly;
    }

    int in_circle(const Ellipse &e4);
    
    bool permuted() const { return index[0] != 0; }

};

int in_circle(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, const Ellipse &e4);

#endif
