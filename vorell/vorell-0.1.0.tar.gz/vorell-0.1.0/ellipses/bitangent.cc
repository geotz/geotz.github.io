/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "bitangent.h"
#include "bisectorx.h"

// deg(P) = 4
upolz_t btan_poly(const QQ ai, const QQ bi, const QQ wi, const QQ xci, const QQ yci,
                 const QQ aj, const QQ bj, const QQ wj, const QQ xcj, const QQ ycj)
{
    upolq_t poly(5, AsSize());
    QQ t110, t112, t105, t107, t235, t263, t284, t312, t266, t281,
    t106, t232, t254, t288, t125, t306, t290, t315, t109, t238,
    t291, t311, t301, t267, t229, t218, t219, t153, t230, t101,
    t100, t225, t154, t140, t104, t296, t119, t111, t234, t293,
    t123, t314, t255, t313, t108, t236, t308, t113, t220, t283,
    t221, t195, t307, t300, t299, t227, t297, t294, t201, t203,
    t228, t210, t80, t276, t275, t273, t205, t181, t241, t180,
    t237, t212, t216, t268, t259, t253, t252, t250, t249, t244,
    t243, t240, t239, t226, t224, t223, t222, t214, t207, t206,
    t202, t200, t160, t152, t142, t141, t137, t128, t127, t124,
    t121, t118;

    t110 = wj*wj;
    t112 = t110*t110;
    t105 = wi*wi;
    t107 = wi*t105;
    t235 = ycj-yci;
    t263 = 8*t235;
    t284 = t107*t263;
    t312 = -2*xcj+2*xci;
    t266 = 4*t235;
    t281 = t107*t266;
    t106 = t105*t105;
    t232 = xcj-xci;
    t254 = t106*t232;
    t288 = wi*t266;
    t125 = -t288-t281+2*t254+t312;
    t306 = 4*xci-4*xcj;
    t290 = wi*t263;
    t315 = ((t290+t284-4*t254-t306)*t110-t125*t112-t125)*ai;
    t109 = aj*aj;
    t238 = -2*t106-2;
    t291 = t106+1;
    t311 = t232*t235;
    t301 = -t107+wi;
    t267 = 6*t235;
    t229 = xci*xcj;
    t218 = -2*t229;
    t219 = -xci*xci-xcj*xcj;
    t153 = t218-t219;
    t230 = ycj*yci;
    t101 = ycj*ycj;
    t100 = yci*yci;
    t225 = -t101-t100;
    t154 = -2*t230-t225;
    t140 = -t153+t154;
    t104 = bj*bj;
    t296 = t104-t109;
    t119 = 2*t301*(-t140+t296);
    t111 = t110*wj;
    t234 = -t111+wj;
    t293 = t296*t234;
    t123 = -t311-2*t293;
    t314 = (-(-t119-t232*(t105*t267-t291*t235))*t112+(t232*t267+12*t293)*
t105-(t301*(-12*t109+12*t104+4*t140)+(-12*t105-t238)*t311)*t110+t123*
t106+t119+t123)*ai;
    t255 = t112+1;
    t313 = t255*t291;
    t108 = ai*ai;
    t236 = t108*bi;
    t308 = t312*t236;
    t113 = bi*bi;
    t220 = t113*t110;
    t283 = -2*t291*t220;
    t221 = t113*t105;
    t195 = t112*t221;
    t307 = -2*t195+t283;
    t300 = t290-t284;
    t299 = t288-t281;
    t227 = t113*t107;
    t297 = 8*t234*t227;
    t294 = t301*t232;
    t201 = t104*t220;
    t203 = xci*t220;
    t228 = t113*xci;
    t210 = xcj*t228;
    t80 = 2*t210;
    t276 = t112*t80+4*xcj*t203+t80+4*t201;
    t275 = -16*t294;
    t273 = -8*t294;
    t205 = xcj*t227;
    t181 = t221*t230;
    t241 = 4*t104;
    t180 = t105*t210;
    t237 = t113*wi;
    t212 = xcj*t237;
    t216 = yci*t237;
    t268 = -4*xci*t216+8*t181-4*t180+(t306*t227+4*t212)*yci+(-4*
t212+4*t205+(4*wi-4*t107)*t228)*ycj+(t241-2*t219)*t221;
    t259 = 4*t106;
    t253 = 2*t104-t113;
    t252 = t113*t109*t313;
    t250 = ((-2-4*t110)*t221+t307)*t108;
    t249 = 4*bi;
    t244 = -4*t104;
    t243 = 8*t109;
    t240 = 2*t109;
    t239 = t259+4;
    t226 = t109-2*t104;
    t224 = 2*t219;
    t223 = -t104+t240;
    t222 = 2*t225;
    t214 = 4*t105;
    t207 = t111*t237;
    t206 = t110*t236;
    t202 = t105*t220;
    t200 = t109*t221;
    t160 = t222+t253;
    t152 = -4*t230-t222;
    t142 = t152-t153;
    t141 = 4*t229+t154+t224;
    t137 = t255*(-yci-t106*ycj)*t108;
    t128 = 2*(t142+t226)*t105-t219;
    t127 = 4*t255*(t106*yci+ycj)*t236+4*(wi+t107)*(t306*t206+t308*t112+
t308)+8*(-t106+1)*t206*t235;
    t124 = (t141+t223)*t214+t160;
    t121 = (-t108+t219)*t313;
    t118 = -16*t105*t201+t104*t297+t268*t112+t268+t252+8*t104*t207+(20*
t200+16*t181-8*t180)*t110+(t243-8*t104)*wj*t237-2*t200+t276*t106+t276+
t250-t225*(-4*t221-4*t195-8*t202)+(-8*t207-t297+t307)*t109-t219*(4*
t202+t283)-8*t232*(wi*ycj*t220-t110*t216)+8*(-t107*t203+t110*t205)*t235;
    
    poly[0] = (t315+t121)*t113+t118;
    poly[1] = t127+(t137+t314)*t249;
    poly[2] = 2*(t218+t153*t106+t128+(-t219*t106+t299*xcj+(t238*xcj-t299)*
xci+t128)*t112+(t240+t244+t300*xcj+2*(-t219+t226)*t106+(-t239*xcj-t300)*xci+(
-5*t109+t241+t142)*t214-t224)*t110+t301*(8*t293+t232*t266))*t113+2*(4*
t230+(-t152+t253)*t106+t124+(t243-4*t100+t244-4*t101+t275*yci+(t223+t225)*
t259+((8+8*t106)*yci-t275)*ycj+8*(5*t104-4*t109+t141)*t105)*t110+(
t273*yci+t160*t106+(t239*yci-t273)*ycj+t124)*t112+t301*(16*t293+t232*t263))*
t108+2*t250-2*t252;
    poly[3] = (t137-t314)*t249+t127;
    poly[4] = (-t315+t121)*t113+t118;
    
    return primpart(poly);
}

upolz_t tan_poly_xy(const QQ a, const QQ b, const QQ w, const QQ xc, const QQ yc, 
                    const QQ x, const QQ y)
{
    upolq_t poly(3, AsSize());
    QQ t6, t5, t4, t3, t8, t9;

    t6 = y-yc;
    t5 = xc-x;
    t3 = w*w;
    t4 = 2*w;
    t9 = (-t5*t3-t6*t4+t5)*b;
    t8 = (t3+1)*b*a;
    poly[0] = 2*t9+2*t8;
    poly[1] = 4*(t6*t3-t5*t4-t6)*a;
    poly[2] = -2*t9+2*t8;
    
    return primpart(poly);
}

upoli_t tan_poly_xy(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, 
                    const IntF x, const IntF y)
{
    upoli_t poly(3, AsSize());
    IntF t6, t5, t4, t3, t8, t9;

    t6 = y-yc;
    t5 = xc-x;
    t3 = w*w;
    t4 = 2*w;
    t9 = (-t5*t3-t6*t4+t5)*b;
    t8 = (t3+1)*b*a;
    poly[0] = 2*t9+2*t8;
    poly[1] = 4*IntF(IntF(t6*t3-t5*t4)-t6)*a;
    poly[2] = -2*t9+2*t8;
    
    return poly;
}

// deg(P) = 2
upoli_t tan_poly_cut(const IntF a1, const IntF b1, const IntF w1, const IntF xc1, const IntF yc1,
        const IntF a2, const IntF b2, const IntF w2, const IntF xc2, const IntF yc2, const IntF t)
{
    upoli_t poly(3, AsSize());
    IntF t37, t39, t79, t60, t77, t76, t38, t73, 
       t72, t53, t42, t68, t71, t54, t41, t40;
    IntF c;

    t37 = w1*w1;
    t39 = t*t;
    t79 = t37*t39+IntF(1);
    t60 = t*a1;
    t77 = -4*w1*t60;
    t76 = t79*b1;
    t38 = w2*w2;
    t73 = -t38-1;
    t72 = ((-4+4*t37)*w2-(4*t38-4)*w1)*a2*t60;
    t53 = t37*t38;
    t42 = t53-t37+IntF(1)-t38+4*w1*w2;
    t68 = -t39+1;
    t71 = t68*a2*t42;
    t54 = b1*t39;
    t41 = (IntF(-xc1)*IntF(-t39-t37)+t79*xc2)*t73;

    t40 = IntF(a1+xc2)*IntF(t53+t37)*b1+IntF(-IntF(t77+t76)*xc1+IntF(t77-t54)*xc2+IntF(-t54-t76)*a1+
          IntF(yc2-yc1)*IntF(IntF(-2*t37+2)*t60+IntF(-2*t54+2*b1)*w1))*t73;
    
    c = 2*IntF(t41-t71)*b1+2*t72+2*t40;
    poly[0] = c;
    c = IntF(8)*(-t42*t60-t68*(w1-w1*t38+t37*w2-w2)*b1)*b2;
    poly[1] = c;
    c = -2*t72+2*IntF(t41+t71)*b1+2*t40;
    poly[2] = c;
    return poly;
}

int tan_poly_sign(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, 
        const IntF x, const IntF y, const IntF t)
{
    IntF t3, t8, t7, t5, t4, t2, res;
    t3 = 2*yc-2*y;
    t8 = w*t3;
    t7 = xc-x;
    t5 = a-t7;
    t4 = a+t7;
    t2 = w*w;
    res = IntF(2)*(2*yc-2*y-4*t7*w-t2*t3)*t*a+ IntF(2)*(t8+t5*t2+(-1*t8+t4*t2+t5)*t*t+t4)*b;
    return Sign(res);
}

int Bitangent::get_external()
{
    if (ext_ > -1) return ext_;
    if (!is_solved()) solve();
    if (size() < 4) {  // TODO: should be < 3
        std::cerr << "ERROR: intersecting ellipses!\n";
        abort();
    }
    
    upolz_t tan11 = tan_poly_xy(ELLIPSE_PC(e1_), e1_.pc[3], e1_.pc[4]);
    upolz_t tan12 = tan_poly_xy(ELLIPSE_PC(e1_), e2_.pc[3], e2_.pc[4]);
    
    //TODO: take into account known sign of e1 !! (always positive!)
    int btype1 = AK::sign_at(tan11, sol[0]) * AK::sign_at(tan12, sol[0]);
    int btype2 = AK::sign_at(tan11, sol[1]) * AK::sign_at(tan12, sol[1]);

    if (!(btype1>0 && btype2<0)) {              // not [1,-1]
        if (btype1<0 && btype2<0) {          // [-1,-1]
            ext_ = 3;
        } else if (btype1<0 && btype2>0) {     // [-1,1]
            ext_ = 2;
        } else {                                         // [1,1]
            ext_ = 1;
        }
    } else { // [1,-1]
        ext_ = 0;
    }
    return ext_;
}

bool Bitangent::is_between(Root t)
{
    int x = get_external();
    if (x == 0) {
        return (t > get_sol(x)) && (t < get_sol((x+3)%4));
    } else {
        return (t > get_sol(x)) || (t < get_sol((x+3)%4));
    }
}

void Bitangent::approx_tan_point(IntF &x, IntF &y)
{
    x = ellipse_x(ELLIPSE_PCX(e1_), INTERVAL(get_sol(get_external())));
    y = ellipse_y(ELLIPSE_PCX(e1_), INTERVAL(get_sol(get_external())));
}

/*bool Bitangent::is_between(Float t)
{
    assert ( ext_ > -1 );
    if (ext_ == 0) {
        return (t > to_double(get_sol(ext_))) && (t < to_double(get_sol((ext_+3)%4)));
    } else {
        return (t < to_double(get_sol(ext_))) || (t < to_double(get_sol((ext_+3)%4)));
    }
}*/

VORELL::Range<Root> visible_range(Bitangent &bt12, Bitangent &bt13)
{
    bt12.solve();
    VORELL::Range<Root> t12 = bt12.chrange();
    
//    std::cerr << "range12 = " << t12 << std::endl;
    
    bt13.solve();
    VORELL::Range<Root> t13 = bt13.chrange();
//    std::cerr << "range13 = " << t13 << std::endl;
    
    VORELL::Range<Root> trange = t12.intersection(t13);
//    std::cerr << "range = " << trange << std::endl;
    return trange;
}
