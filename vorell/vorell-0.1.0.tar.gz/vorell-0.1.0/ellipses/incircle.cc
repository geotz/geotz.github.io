/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

/* 
    optimizations done:

    1. use primpart() and also divide out known factors
    2. pre-computed determinant expression with Maple for small matrix (10x10) ~ 75sec
    3. use univariate poly instead of multivariate where only 1 var appears ~ 40sec
    4. use integer arithmetic instead of rational  ~ 13sec
    5. use interpolation in inner determinant ~ 9.42sec
    6. slightly faster interpolation routine (from book) ~ 9.38sec
    7. ALGEBRIX / GMPXX instead of NUMERIX ~ 7.5sec
    8. NTL resultant ~ 4.9sec
*/

#include <time.h>

#include "ellipse.h"
#include "incircle.h"
#include "incircle_eval.h"
#include "parnorm.h"
#include "bitangent.h"
#include "bisector_tr.h"
#include "bisectorx.h"
#include "pred_k2.h"
#include "exception.h"

void EllipseTriplet::compute_bitangents()
{
    if (bitangents_computed) return;

    bt12_ = Bitangent(e1_, e2_); bt21_ = Bitangent(e2_, e1_);
    bt13_ = Bitangent(e1_, e3_); bt31_ = Bitangent(e3_, e1_);
    bt23_ = Bitangent(e2_, e3_); bt32_ = Bitangent(e3_, e2_);
    
    bitangents_computed = true;
}

void EllipseTriplet::compute_bisectors()
{
    if (bisectors_computed) return;
    
    b12_ = Bisector(e1_, e2_, 1, 2);
    b13_ = Bisector(e1_, e3_, 1, 3);
    
    bisectors_computed = true;
}

void EllipseTriplet::compute_parnormals()
{
    if (parnormals_computed) return;
    
    p12_ = parnorm(ELLIPSE_PC(e1_), ELLIPSE_PC(e2_));
    p13_ = parnorm(ELLIPSE_PC(e1_), ELLIPSE_PC(e3_));
    
    parnormals_computed = true;
}



void EllipseTriplet::compute_ranges()
{
    if (ranges_computed) return;
    
    compute_bitangents();
    trange = visible_range(bt12_, bt13_);
    rrange = visible_range(bt23_, bt21_);
    srange = visible_range(bt31_, bt32_);
#ifdef VERBOSE
    std::cerr << "trange = " << trange << std::endl;
    std::cerr << "rrange = " << rrange << std::endl;
    std::cerr << "srange = " << srange << std::endl;
#endif

    ranges_computed = true;
}

/* returns value:
    0 = no external tritangent circle exists
    1 = only 1 (ccw) circle exists
   -1 = only 1 (cw) circle exists
    2 = both cw & ccw circles exist
*/
int EllipseTriplet::count_voronoi_circles()
{
    int c1, c2, l1, l2;
    
    compute_bitangents();
    
    // TODO: recomputes same stuff!
    l1 = (distance_from_bitangent_wbtan(e1_, e2_, e3_, &c1, bt12_, bt13_) < 0);
    l2 = (distance_from_bitangent_wbtan(e2_, e1_, e3_, &c2, bt21_, bt23_) < 0);
    
    // TODO: works only for non-inter. ellipses
    RangeF vr, vt;
    int v = visible_arc_generic(e2_, INTERVAL(e3_.get_xc()), INTERVAL(e3_.get_yc()), vr);
    assert(v == 0);
    v = visible_arc_generic(e1_, INTERVAL(e3_.get_xc()), INTERVAL(e3_.get_yc()), vt);
    assert(v == 0);
    
    // TODO: optimize this -- should not get recomputed
    bool inside = bt21_.chrange().containsi(vr.a) && bt12_.chrange().containsi(vt.a);
    
    // old incorrect version
    //int o2 = e2_.ccw(e3_.get_xc(), e3_.get_yc(), e2_.get_xc(), e2_.get_yc(), r2);
    //int o1 = e1_.ccw(e3_.get_xc(), e3_.get_yc(), e1_.get_xc(), e1_.get_yc(), t1);
    
    if (l1 == 0 && l2 == 0) {
        //if (o1 != o2) return 2;
        if (inside) return 2;
        return 0;
    }
    
    if (l1 == 0 && l2 == 1) {
        return 1;
    }
    
    if (l1 == 1 && l2 == 0) {
        return -1;
    }
    
    // l1 == 1 && l2 == 1
    
    compute_ranges();
    if (trange.is_empty() || rrange.is_empty() || srange.is_empty()) return 0;
    
    return 2;
}

int EllipseTriplet::get_num_voronoi_circles()
{
    if (num_voronoi_circles == -100) {
        num_voronoi_circles = count_voronoi_circles();
    }
    return num_voronoi_circles; 
}

EllipseTriplet::EllipseTriplet(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, bool fixed_order)
{ 
    const Ellipse *e[3];
    int _index[3] = {0, 1, 2};
    e[0] = &e1; e[1] = &e2; e[2] = &e3;
    resultant_computed = false; 
    bitangents_computed = false;
    bisectors_computed = false;
    num_voronoi_circles = -100;
    parnormals_computed = false;
    ranges_computed = false;
    vc_computed = false;

    // sort circles to come before, retaining cyclic order ;-)
    ncircles = 0;
    int i;
    for (i = 0; i < 3; i++) ncircles += e[i]->is_circle();
    
    if (!fixed_order) {
        if (ncircles == 1) { // 1 circle
            for (i = 0; i < 3; i++) if (e[i]->is_circle()) break; // find it
            if (i == 1) {
                _index[0] = 1; _index[1] = 2; _index[2] = 0;
            } else if (i == 2) {
                _index[0] = 2; _index[1] = 0; _index[2] = 1;
            }
        } else if (ncircles == 2) { // two circles
            for (i = 0; i < 3; i++) if (!e[i]->is_circle()) break; // find ellipse
            if (i == 0) {
                _index[0] = 1; _index[1] = 2; _index[2] = 0;
            } else if (i == 1) {
                _index[0] = 2; _index[1] = 0; _index[2] = 1;
            }
        }
    }
    e1_ = *e[_index[0]]; e2_ = *e[_index[1]]; e3_ = *e[_index[2]];
    index[0] = _index[0]; index[1] = _index[1]; index[2] = _index[2];

    //TODO: cw and ccw triplets have the same resultant -- just some signs change...
    // also, we could cache shifted (cyclic) triplets -- attention on index update, also Q, Dtr, Dth change,
    // since the order of variables changes

#ifndef NOHASH
    if (cache.load(*this)) {
/*        index[0] = _index[0]; index[1] = _index[1]; index[2] = _index[2];
        if (vc_computed)
            vc.index[0] = index[0]; vc.index[1] = index[1]; vc.index[2] = index[2];*/
        return;
    }
#endif
    
    Q = ell_normals(ELLIPSE_PC(e1_), ELLIPSE_PC(e2_), ELLIPSE_PC(e3_));
    
#ifdef VERBOSE
    std::cerr << "Q := " << Q << ':' << std::endl;
    compute_bisectors();
    std::cerr << "B12 := " << b12_.bpoly() << ':' << std::endl;
    std::cerr << "B13 := " << b13_.bpoly() << ':' << std::endl;
#endif
}

void EllipseTriplet::compute_resultant_EEE()
{
    mpolz_t B12 = b12_.bpoly();
    mpolz_t B13 = b13_.bpoly();

#ifdef VERBOSE
    std::cerr << "p12 := " << p12_ << ':' << std::endl;
    std::cerr << "p13 := " << p13_ << ':' << std::endl;
#endif
    
    mpolz_t Qt;
    upolz_t Qts, B12t, res1t, B13t;
    ZZ t_, res, xval[185], yval[185], rxval[25], ryval[25];
    clock_t st, dt;

#ifdef VERBOSE
    std::cerr << "interpolating resultant ";
#endif
    st = clock();

    // interpolation for 185 values
    for (int i = -92; i <= 92; i++) {
        t_ = ZZ(i);
        xval[i+92] = t_;

        B12t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B12),2 );
	Qt = subs(1, t_, Q);

        // interpolation for 25 values
        for (int j = -12; j <= 12; j++) {
            rxval[j+12] = ZZ(j);
            Qts = mpol2u<upolz_t, mpolz_t>(subs(3, ZZ(j), Qt), 2);
            //ryval[j+12] = calc_res_qb_ts(Qts, B12t);
            mmx::FAST::resultant(Qts, B12t, ryval[j+12]);
//                cerr << ryval[j+12] << endl;
        }
        res1t = interpolate(25, rxval, ryval);
        res1t = upolz_divby(res1t, p12_(t_) * pow(ZZ(1+pow(t_,2)),4));

	B13t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B13),3);

	//res = sylvester_resultant(B13t, res1t);
        mmx::FAST::resultant(B13t, res1t, res);
	res = res / (pow(p13_(t_), 6)*pow(ZZ(1+pow(t_,2)),28));
        yval[i+92] = res;
#ifdef VERBOSE
        std::cerr << '.';
#endif
//            cerr << res << endl;
    }
    dt = clock()-st;
#ifdef VERBOSE
    std::cerr << std::endl << "time/iteration: " << dt/185.0 << std::endl;
#endif
    st = clock();

    respoly = primpart(interpolate(185, xval, yval));
    
    
/*    std::ofstream dump("res184.dat");
    dump << respoly << std::endl;
    //for (int i = 0; i < 185; i++) dump << respoly[i] << std::endl;
    dump.close();*/
    
    dt = clock()-st;
    
#ifdef VERBOSE
    std::cerr << "interpolation time: " << dt << std::endl;
#endif    

    resultant_computed = true;
}

void EllipseTriplet::compute_resultant_CEE()
{
    mpolz_t B12 = b12_.bpoly();
    mpolz_t B13 = b13_.bpoly();

#ifdef VERBOSE
    std::cerr << "p12 := " << p12_ << ':' << std::endl;
    std::cerr << "p13 := " << p13_ << ':' << std::endl;
#endif

    mpolz_t Qt;
    upolz_t Qts, B12t, res1t, B13t;
    ZZ t_, t2_plus_1, res, xval[73], yval[73], rxval[25], ryval[25];
    clock_t st, dt;

#ifdef VERBOSE
    std::cerr << "interpolating resultant ";
#endif
    st = clock();

    // interpolation for 73 values
    for (int i = -36; i <= 36; i++) {
        t_ = ZZ(i);
        xval[i+36] = t_;
        t2_plus_1 = 1+pow(t_,2);

        B12t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B12),2 );
	Qt = subs(1, t_, Q);

        // interpolation for 25 values
        for (int j = -12; j <= 12; j++) {
            rxval[j+12] = ZZ(j);
            Qts = mpol2u<upolz_t, mpolz_t>(subs(3, ZZ(j), Qt), 2);
            Qts = upolz_divby(Qts, t2_plus_1);
            mmx::FAST::resultant(Qts, B12t, ryval[j+12]);
        }
        res1t = interpolate(25, rxval, ryval);
        res1t = upolz_divby(res1t, p12_(t_));

	B13t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B13),3);

        mmx::FAST::resultant(B13t, res1t, res);
	res = res / pow(p13_(t_), 6);
        yval[i+36] = res;
#ifdef VERBOSE
        std::cerr << '.';
#endif
    }
    dt = clock()-st;
    
#ifdef VERBOSE
    std::cerr << std::endl << "time/iteration: " << dt/73.0 << std::endl;
#endif
    st = clock();

    respoly = primpart(interpolate(73, xval, yval));
    dt = clock()-st;
    
#ifdef VERBOSE
    std::cerr << "interpolation time: " << dt << std::endl;
#endif
//    std::cerr << respoly << std::endl;
    
    resultant_computed = true;
}

void EllipseTriplet::compute_resultant_CCE()
{
    mpolz_t B12 = b12_.bpoly();
    mpolz_t B13 = b13_.bpoly();

#ifdef VERBOSE
    std::cerr << "p12 := " << p12_ << ':' << std::endl;
    std::cerr << "p13 := " << p13_ << ':' << std::endl;
#endif
    
    mpolz_t Qt;
    upolz_t Qts, B12t, res1t, B13t;
    ZZ t_, t2_plus_1, res, xval[13], yval[13], rxval[5], ryval[5];
    clock_t st, dt;

#ifdef VERBOSE
    std::cerr << "interpolating resultant ";
#endif
    st = clock();

    // interpolation for 13 values
    for (int i = -6; i <= 6; i++) {
        t_ = ZZ(i);
        xval[i+6] = t_;
        t2_plus_1 = 1+pow(t_,2);

        B12t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B12),2 );
	Qt = subs(1, t_, Q);
        //std::cerr << "Qt = " << Qt << std::endl;
        
        // interpolation for 5 values
        for (int j = -2; j <= 2; j++) {
            rxval[j+2] = ZZ(j);
            Qts = mpol2u<upolz_t, mpolz_t>(subs(3, ZZ(j), Qt), 2);
            Qts = upolz_divby(Qts, t2_plus_1);
            Qts = quo(Qts, upolz_t("1+x^2")); // 1+r^2
            //std::cerr << "Qts = " << Qts << std::endl;
            mmx::FAST::resultant(Qts, B12t, ryval[j+2]);
            //std::cerr << "ryval " << ryval[j+2] << std::endl;
        }
        res1t = interpolate(5, rxval, ryval);
        res1t = upolz_divby(res1t, p12_(t_));

	B13t = mpol2u<upolz_t,mpolz_t>(subs(1, t_, B13),3);

        mmx::FAST::resultant(B13t, res1t, res);
	res = res / p13_(t_);
        yval[i+6] = res;
#ifdef VERBOSE
        std::cerr << '.';
#endif
    }
    dt = clock()-st;
#ifdef VERBOSE
    std::cerr << std::endl << "time/iteration: " << dt/13.0 << std::endl;
#endif
    st = clock();

    respoly = primpart(interpolate(13, xval, yval));
    dt = clock()-st;
#ifdef VERBOSE
    std::cerr << "interpolation time: " << dt << std::endl;
#endif
//    std::cerr << respoly << std::endl;
    
    resultant_computed = true;
}

void EllipseTriplet::compute_resultant() 
{ 
    if (resultant_computed) return;

    compute_bisectors();
    compute_parnormals(); // TODO: NOTE: CCC does not need it, but used in decision

    if (e1_.is_circle()) {
        if (e2_.is_circle()) {
            if (e3_.is_circle()) {
                compute_resultant_CCC();
            } else compute_resultant_CCE();
        } else {
            compute_resultant_CEE();
        }
    } else compute_resultant_EEE();

    return; 
}

void EllipseTriplet::compute_resultant_CCC()
{
    respoly = ell_resultant_CCC(e1_.pc[0], e1_.pc[3], e1_.pc[4], e2_.pc[0], e2_.pc[3], e2_.pc[4],
                            e3_.pc[0], e3_.pc[3], e3_.pc[4]);

    resultant_computed = true;
#ifndef NOHASH
    cache.update(*this);
#endif
}

void EllipseTriplet::compute_voronoi_circle()
{
    if (vc_computed) return;
    
    vc = VoronoiCircle(*this);
    vc_computed = true;
#ifndef NOHASH
    cache.update(*this);
#endif
}


// returns -2 if we cannot decide
int EllipseTriplet::in_circle_with_subdivision(const Ellipse &e4)
{
    Bitangent bt14 = Bitangent(e1_, e4);
    VORELL::Range<Root> trange2 = visible_range(bt12_, bt14);
#ifdef VERBOSE
    std::cerr << "trange123 = " << trange << std::endl;
    std::cerr << "trange124 = " << trange2 << std::endl;
#endif
    if (trange.intersection(trange2).is_empty()) return 1;

    compute_voronoi_circle();
#ifdef VERBOSE
    std::cerr << vc << std::endl;
#endif
    
//    if (!trange2.contains(vc.tsol)) return 1;
    IntF t = vc.solx[0];
    if (!trange2.containsi(t)) return 1;
    
    EllipseTriplet t124(e1_, e2_, e4, true);
    
    IntF r = vc.solx[1];
    BisectorX bx14 = BisectorX(e1_, e4);
    IntF h = bx14.solve(t);
#ifdef VERBOSE
    std::cerr << "h = " << h << std::endl;
#endif
#ifdef VERBOSE
    std::cerr << "hash124 = " << t124.hash() << std::endl;
#endif
    int sQ = sign_of_Q(ELLIPSE_PCX(e1_), ELLIPSE_PCX(e2_), ELLIPSE_PCX(e4), t, r, h);
    if (sQ != 0) { // TODO: check Dtr and Dth...
        int sDtr = sign_of_D(ELLIPSE_PCX(e1_), ELLIPSE_PCX(e2_), t, r);
        int sDth = sign_of_D(ELLIPSE_PCX(e1_), ELLIPSE_PCX(e4), t, h);
        return sQ * sDtr * sDth;
    }
#ifdef VERBOSE
    std::cerr << "possible INCIRCLE degeneracy" << std::endl;
#endif
    return -2;
}

// TODO: compute all ranges for query ellipse and compare like trange2
int EllipseTriplet::in_circle(const Ellipse &e4)
{
    if (get_num_voronoi_circles() < 1) return -1;
    
    compute_ranges();
    
    int r = in_circle_with_subdivision(e4);
    if (r != -2) return r;
    
    compute_resultant();
    EllipseTriplet t124(e1_, e2_, e4, true);
    upolz_t res124 = t124.resultant();
    
    upolz_t res_gcd;
    mmx::FAST::GCD(respoly, res124, res_gcd);
#ifdef VERBOSE
    std::cerr << "degree(gcd) = " << degree(res_gcd) << std::endl;
#endif
    
    
// TODO: fix this matching
    
    bool found = false;
    RootSeq::const_iterator git;
    RootSeq gsol;
    if (degree(res_gcd) > 0) {
        gsol = mmx::actual_solve(res_gcd, NCF<ZZ>());  

        IntF gapx;
        if (degree(res_gcd) > 0) for (git = gsol.begin(); git != gsol.end(); git++) {
            gapx = INTERVAL(*git);
            if (gapx < vc.solx[0]) continue;
            if (gapx > vc.solx[0]) continue;
    #ifdef VERBOSE
            std::cerr << "suspect (gcd): " << gapx << "//" << vc.solx[0] << std::endl; 
    #endif
            found = true;
            break;
        }
    }
    
    if (found) {
        RootSeq r1sol = mmx::actual_solve(respoly, NCF<ZZ>());  
        RootSeq::const_iterator r1it;
        IntF r1apx;
        for (r1it = gsol.begin(); r1it != gsol.end(); r1it++) {
            r1apx = INTERVAL(*r1it);
            if (r1apx < vc.solx[0]) continue;
            if (r1apx > vc.solx[0]) continue;
#ifdef VERBOSE
            std::cerr << "suspect (res1): " << r1apx << "//" << vc.solx[0] << std::endl; 
#endif
            found = true;
            break;
        }
        if (found) {
            RootSeq r2sol = mmx::actual_solve(respoly, NCF<ZZ>());  
            RootSeq::const_iterator r2it;
            IntF r2apx;
            for (r2it = gsol.begin(); r2it != gsol.end(); r2it++) {
                r2apx = INTERVAL(*r2it);
                if (r2apx < vc.solx[0]) continue;
                if (r2apx > vc.solx[0]) continue;
#ifdef VERBOSE
                std::cerr << "suspect (res2): " << r2apx << "//" << vc.solx[0] << std::endl; 
#endif
                found = true;
                break;
            }
            if (found) {
                if (*r1it == *r2it && *r1it == *git) return 0;
            }
        }
    }
    
    std::cerr << "NON-DEGENERATE -- higher precision needed to decide !!\n";
    abort();
        
    
/*    if (e4.is_circle() && e3_.is_circle()) {   // ALL CIRCLES
        t124.compute_resultant();
        int sQ = AK::sign_at(t124.respoly, vc.tsol);
        int sDtr = AK::sign_at(p12_, vc.tsol) * AK::sign_at(b12_.poly_CC_tt(), vc.tsol);
        int sDth = AK::sign_at(t124.p13_, vc.tsol) * AK::sign_at(t124.b13_.poly_CC_tt(), vc.tsol);
        return sQ * sDtr * sDth;
    }*/
    
//    std::cerr << "incircle inexact!" << std::endl;

}




// returns 1 on sucessful refinement, 0 if precision limit reached
// TODO: have to make it faster by not computing apoll.arc every time
// we can use refined r2r1  instead!!
int VoronoiCircle::refine_t() 
{
    Float t1, t1b;
    IntF r2, s1, t2;

    while (true) {
        // TODO: fix this binary search (with optimal normalization (spm))
        
#ifdef VERBOSE
        info_t();
#endif

        t1 = trange.midpoint();
//        std::cerr << "midpoint t1 = " << t1 << std::endl;
        if (t1 == trange.a) {
            return 0;
        }
        iters++;

        r2 = bx12.solve(t1);
//        std::cerr << "r2 = " << r2 << std::endl;
        if (ch21_.contains(rrange.a) && ch21_.order(r2, rrange.a) < 0) { // r2 too left 
            trange = RangeF(trange.a, t1); // move t1 to the left (moves opposite)
            continue;
        } else if (ch21_.contains(rrange.b) && ch21_.order(r2, rrange.b) > 0) { // r2 too right
            trange = RangeF(t1, trange.b); // move t1 to the right
            continue;
        }

        s1 = bx23.solve(r2);
//        std::cerr << "s1 = " << s1 << std::endl;
        if (ch32_.contains(srange.a) && ch32_.order(s1, srange.a) < 0) { // s1 too left 
            trange = RangeF(t1, trange.b); // move t1 to the right (moves the same)
            continue;
        } else if (ch32_.contains(srange.b) && ch32_.order(s1, srange.b) > 0) { // s1 too right
            trange = RangeF(trange.a, t1); // move t1 to the left
            continue;
        }

        t2 = bx31.solve(s1);
//        std::cerr << "t2 = " << t2 << std::endl;
        if (ch13_.contains(trange.a) && ch13_.order(t2, trange.a) < 0) { // t2 too left
            trange = RangeF(trange.a, t1); // move t1 to the left (moves opposite)
            continue;
        } else if (ch13_.contains(trange.b) && ch13_.order(t2, trange.b) > 0) { // t2 too right
            trange = RangeF(t1, trange.b); // move t1 to the right
            continue;
        }

        break;
    }

//     t1 r2 s1 t2 computed sucessfully
    Float w;
    bool tf = trange.is_finite();
    if (tf) w = trange.width();
    if (tf) {
        if (t2 > t1) trange = RangeF(t1, t2.upper());
        else if (t2 < t1) trange = RangeF(t2.lower(), t1);
        else trange = RangeF(t2.lower(), t2.upper()); // TODO: consider intersection with old?
    } else {
        if (t2 > t1 || t2 < t1) {
            if (trange.orderi(t1, t2) == -1) trange = RangeF(t1, t2.upper());
            else trange = RangeF(t2.lower(), t1);
        } else trange = RangeF(t2.lower(), t2.upper()); // TODO: consider intersection with old?
    }
    if (tf && trange.width() >= w) return 0;
    return 1;
}

void VoronoiCircle::refine_rs() {
    IntF tmp;
    tmp = bx12.solve(trange.interval());
    rrange = RangeF(tmp.lower(), tmp.upper());
    tmp = bx23.solve(rrange.interval());
    srange = RangeF(tmp.lower(), tmp.upper());
#ifdef VERBOSE
    info_all();
#endif
}

void VoronoiCircle::info_t() {
    std::cerr << "trange = " << trange;
    if (trange.is_finite()) std::cerr << trange.width() << "-->" << trange.width()*trange.width();
    else std::cerr << "INFINITE";
    std::cerr << std::endl;
}

void VoronoiCircle::info_all() {
    std::cerr << "RANGES:\n";
    std::cerr << "trange = " << trange;
    if (trange.is_finite()) std::cerr << trange.width();
    std::cerr << std::endl;
    std::cerr << "rrange = " << rrange;
    if (rrange.is_finite()) std::cerr << rrange.width();
    std::cerr << std::endl;
    std::cerr << "srange = " << srange;
    if (srange.is_finite()) std::cerr << srange.width();
    std::cerr << std::endl;
    if (trange.is_finite() && rrange.is_finite())
        std::cerr << "btr = " << bx12.polyx(trange.interval())(rrange.interval()) << std::endl;
    if (rrange.is_finite() && srange.is_finite())
        std::cerr << "brs = " << bx23.polyx(rrange.interval())(srange.interval()) << std::endl;
    if (srange.is_finite() && trange.is_finite())
        std::cerr << "bst = " << bx31.polyx(srange.interval())(trange.interval()) << std::endl;
}

void VoronoiCircle::approx_with_subdivision(EllipseTriplet &t123)
{
//    std::cerr << "ta/tb = " << ta << '/' << tb << std::endl;
    trange = RANGE(t123.trange);
//    std::cerr << "ta/tb = " << ta << '/' << tb << std::endl;
    rrange = RANGE(t123.rrange);
//    std::cerr << "ta/tb = " << ta << '/' << tb << std::endl;
    srange = RANGE(t123.srange);
    
    ch21_ = RANGE(t123.bt21_.chrange());
    ch32_ = RANGE(t123.bt32_.chrange());
    ch13_ = RANGE(t123.bt13_.chrange());
    
    iters = 0;
    
    bx12 = BisectorX(t123.e1_, t123.e2_);
    bx23 = BisectorX(t123.e2_, t123.e3_);
    bx31 = BisectorX(t123.e3_, t123.e1_);

#ifdef VERBOSE
    info_all();
    std::cerr << "SUBDIVISION FOR" << std::endl;
    std::cerr << t123.e1_ << std::endl << t123.e2_ << std::endl << t123.e3_ << std::endl;
#endif
    while (refine_t() == 1);
    refine_rs();
    
    solx[0] = trange.interval(); solx[1] = rrange.interval(); solx[2] = srange.interval();
    subdivision = true;
}

void VoronoiCircle::approx_with_resultant(EllipseTriplet &t123)
{
    upolz_t poly = t123.resultant();

#ifdef VERBOSE
    std::cerr << "deg(res) = " << degree(poly) << std::endl;
    if (degree(poly) > 12)
        std::cerr << poly[degree(poly)] << "*x^" << degree(poly) << " + ... + (" << poly[0] << ")" << std::endl;
    else 
        std::cerr << poly << std::endl;
#endif
    RootSeq sol = mmx::actual_solve(poly, NCF<ZZ>());
#ifdef VERBOSE
    std::cerr << "resultant has " << sol.size() << " real roots\n";
#endif
    BisectorX b12x = BisectorX(t123.b12_);
    BisectorX b13x = BisectorX(t123.b13_);
    BisectorX b23x = BisectorX(t123.e2_, t123.e3_);
    int nf = 0;
    IntF t, r, s, ver;
    for (RootSeq::const_iterator it = sol.begin(); it != sol.end(); it++) {
        t = INTERVAL(*it);
#ifdef VERBOSE
        std::cerr << "t= " << t << t.width() << std::endl;
#endif
        if (!t123.trange.containsi(t)) continue;
        r = b12x.solve(t);
#ifdef VERBOSE
        std::cerr << "r(t)=" << r << r.width() << std::endl;
#endif
        if (!t123.rrange.containsi(r)) continue;
        s = b13x.solve(t);
#ifdef VERBOSE
        std::cerr << "s(t)=" << s << s.width() << std::endl;
#endif
        if (!t123.srange.containsi(s)) continue;
        ver = b23x.polyx(r)(s);
#ifdef VERBOSE
        std::cerr << "B23(r,s)=" << ver << ver.width() << std::endl;
#endif
        if (isign(ver) != 0) continue;
        nf++;
        tsol = *it;
        solx[0] = t; solx[1] = r; solx[2] = s;
//        break;
    }
    if (nf == 0) {
        std::cerr << "voronoi circle does not exist!\n";
        std::cerr << t123.e1_ << std::endl;
        std::cerr << t123.e2_ << std::endl;
        std::cerr << t123.e3_ << std::endl;
        std::cerr << "trange = " << t123.trange << std::endl;
        std::cerr << "rrange = " << t123.rrange << std::endl;
        std::cerr << "srange = " << t123.srange << std::endl;
        abort();
    }
    assert (nf == 1 );

}
VoronoiCircle::VoronoiCircle(EllipseTriplet &t123)
{
    assert (t123.get_num_voronoi_circles() > 0);

    index[0] = t123.index[0];
    index[1] = t123.index[1];
    index[2] = t123.index[2];
    
    t123.compute_ranges();
    subdivision = false;
    
    if (t123.ncircles == 3) approx_with_resultant(t123);    
    else approx_with_subdivision(t123);
}

std::ostream& operator<<(std::ostream& o, const VoronoiCircle& v)
{
    return (o << '(' << v.index[0] << v.index[1] << v.index[2] << ")[" << v.solx[0] << ',' << v.solx[1] << ',' << v.solx[2] << ']');
}

int in_circle(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, const Ellipse &e4)
{
    EllipseTriplet t123(e1, e2, e3);
    return t123.in_circle(e4);
}
