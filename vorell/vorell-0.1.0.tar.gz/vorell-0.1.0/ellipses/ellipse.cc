/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "ellipse.h"
#include "algebra.h"

// *coeff = [a,b,c,d,e,f] = ax^2 + 2bxy + cy^2 + 2dx + 2ey + f
void ell_alg_coeff(const QQ a, const QQ b, const QQ w, const QQ xc, const QQ yc, QQ *coeff)
{
    QQ t4, t14, t20, t22, t21, t19, t18, t17, t6, t16,
       t2, t7, t15, t13, t3, t1,
       tmp;

    t4 = w*w;
    t14 = (1-t4)*w;
    t20 = 2*t14;
    t22 = yc*t20;
    t21 = xc*t20;
    t19 = 4*t14*yc*xc;
    t18 = -4*t4;
    t17 = 4*t4;
    t6 = t4*t4;
    t16 = 1+t6;
    t2 = yc*yc;
    t7 = b*b;
    t15 = t2-t7;
    t13 = -2*t4+t16;
    t3 = a*a;
    t1 = xc*xc;
    coeff[0] = t16*t7+(4*t3-2*t7)*t4;
    coeff[1] = 2*(a-b)*(a+b)*w*(w-1)*(1+w);
    coeff[2] = t7*t17+t13*t3;
    coeff[3] = (xc*t18+t22)*t3+(-t13*xc-t22)*t7;
    coeff[4] = (yc*t18-t21)*t7+(t21-t13*yc)*t3;
    coeff[5] = (t2*t17+t13*t1+t19)*t7+(t15*t6-t19+2*(2*t1-t7-t2)*t4+t15)*t3;
    for (int i = 0; i < 6; i++) coeff[i] = coeff[i] / ((1+w*w)*(1+w*w));
}

void Ellipse::init_coeff(QQ a_, QQ b_, QQ w_, QQ xc_, QQ yc_) {
    // circle?
    if (a_ == b_) w_ = 0;
    
    // set parametric coeffs
    pc[0] = a_; pc[1] = b_; pc[2] = w_; pc[3] = xc_; pc[4] = yc_;
    
    // set algebraic coeffs
    ell_alg_coeff(pc[0], pc[1], pc[2], pc[3], pc[4], ac);
//    seq_primpart(6, acq, ac);
    
    // (pre)compute invariants
    J1 = ac[0] + ac[2];
    J2 = ac[0]*ac[2] - ac[1]*ac[1];
}

int Ellipse::hash() const
{
    QQ a;
    for (int i = 0; i < 5; i++) a += abs(pc[i]);
    ZZ b = (numerator(a) * denominator(a)) % ZZ(ELL_HASH_PRIME);
    return (int) b.get_si();
}

void Ellipse::print_eq(std::ostream& o)
{
    o << '(' << ac[0] << ")*x^2 + " <<
         '(' << 2*ac[1] << ")*x*y + " <<
         '(' << ac[2] << ")*y^2 + " <<
         '(' << 2*ac[3] << ")*x + " <<
         '(' << 2*ac[4] << ")*y + " <<
         '(' << ac[5] << ')';
}

std::ostream& operator<<(std::ostream& o, const Ellipse& x) 
{
//    return (o << x.pc[0] << 'x' << x.pc[1] << '%' << x.pc[2] << '@' << x.pc[3] << ',' << x.pc[4]);
    return (o << x.pc[0] << ' ' << x.pc[1] << ' ' << x.pc[2] << ' ' << x.pc[3] << ' ' << x.pc[4]);
}

std::istream& operator>>(std::istream& i, Ellipse& x) 
{
    QQ pc_[5];
    i >> pc_[0] >> pc_[1] >> pc_[2] >> pc_[3] >> pc_[4];
    x.init_coeff(pc_[0], pc_[1], pc_[2], pc_[3], pc_[4]);
    return i;
}

bool Ellipse::operator==(const Ellipse &x) const
{
    return pc[0] == x.pc[0] && pc[1] == x.pc[1] && pc[2] == x.pc[2] &&
           pc[3] == x.pc[3] && pc[4] == x.pc[4];
}

int Ellipse::ccw(QQ x1, QQ y1, QQ x2, QQ y2, Root t) const
{
    QQ t12, t11, t10, t7, t15, t8;
    upolq_t poly(3, AsSize());
    
    t12 = y1-y2;
    t11 = x2-x1;
    t10 = 2*pc[2];
    t7 = pc[2]*pc[2];
    t15 = (-t12*t7+t11*t10+t12)*pc[0];
    t8 = (t7+1)*(x1*y2-x2*y1+t12*pc[3]+t11*pc[4]);
    poly[0] = t15+t8;
    poly[1] = 2*(-t11*t7-t12*t10+t11)*pc[1];
    poly[2] = -t15+t8;
    
    return AK::sign_at(primpart(poly), t);
}
