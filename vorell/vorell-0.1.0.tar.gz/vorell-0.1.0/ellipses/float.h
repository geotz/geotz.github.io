/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _FLOAT_H_
#define _FLOAT_H_

#include <mpfr.h>
#include <iostream>
#include <string>
#include <cstring>

#include <algebrix/kernel_texp.hpp>
#include "algebra.h"

// quick & dirty mpfr_t encapsulation :-)
class Float
{
    mpfr_t x;

public:
    Float() { mpfr_init(x); }

    Float(const mpfr_t a, const mp_rnd_t rnd = GMP_RNDD) { mpfr_init_set(x, a, rnd); }

    Float(const Float &a, const mp_rnd_t rnd = GMP_RNDD) { mpfr_init_set(x, a.x, rnd); }

    Float(const double a, const mp_rnd_t rnd = GMP_RNDD) { mpfr_init_set_d(x, a, rnd); }

    Float(const int a, const mp_rnd_t rnd = GMP_RNDD) { mpfr_init_set_si(x, (long int) a, rnd); }

    Float(const std::string &s, const mp_rnd_t rnd = GMP_RNDD) { 
        mpfr_init(x);
        if (mpfr_set_str(x, s.c_str(), 10, rnd) < 0) mpfr_set_ui(x, 0, GMP_RNDN);
    }
    
    Float(const ZZ a, const mp_rnd_t rnd = GMP_RNDD) {
        std::string s = a.get_str(32);
        mpfr_init(x);
        size_t bs = s.length() * 5 + 8;
        if (bs > precision()) precision(bs);
        if (mpfr_set_str(x, s.c_str(), 32, rnd) < 0) mpfr_set_ui(x, 0, GMP_RNDN);
    }

    Float(const QQ a, const mp_rnd_t rnd = GMP_RNDD) {
        ZZ num, den;
        Float numer, denom;
        
        mpfr_init(x);
        num = a.get_num();
        den = a.get_den();
        if (sign(den) < 0) num = -num, den = -den;
        
        switch (rnd) {
            case GMP_RNDD: {
                if (sign(num) >= 0) {
                    numer = Float(num, GMP_RNDD);
                    denom = Float(den, GMP_RNDU);
                } else {
                    numer = Float(num, GMP_RNDD);
                    denom = Float(den, GMP_RNDD);
                }
//                precision(numer.precision() + denom.precision());
                mpfr_div(x, numer.x, denom.x, GMP_RNDD);
                break;
            }
                        
            case GMP_RNDU: {
                if (sign(num) >= 0) {
                    numer = Float(num, GMP_RNDU);
                    denom = Float(den, GMP_RNDD);
                } else {
                    numer = Float(num, GMP_RNDU);
                    denom = Float(den, GMP_RNDU);
                }
//                precision(numer.precision() + denom.precision());
                mpfr_div(x, numer.x, denom.x, GMP_RNDU);
                break;
            }
            
            default: { /* TODO: semantics? */
                numer = Float(num, GMP_RNDN);
                denom = Float(den, GMP_RNDN);
//                precision(numer.precision() + denom.precision());
                mpfr_div(x, numer.x, denom.x, GMP_RNDN);
                break;
            }
        }
    }

    ~Float() { mpfr_clear(x); }
    
    void round(const mp_prec_t prec) { mpfr_prec_round(x, prec, GMP_RNDD); }
    void precision(const mp_prec_t prec) { mpfr_set_prec(x, prec); }
    mp_prec_t precision() const { return mpfr_get_prec(x); }
    
    Float& operator=(const Float& f) {
        if (this->precision() < f.precision()) this->round(f.precision());
        mpfr_set(this->x, f.x, GMP_RNDD);
        return *this;
    }
    
    Float operator-() const {
        Float tmp;
        mpfr_neg(tmp.x, x, GMP_RNDD);
        return tmp;
    }

    #define binary_op(opname) Float tmp; \
        mpfr_ ## opname (tmp.x, x, f.x, GMP_RNDD); \
        return tmp;
    
    Float operator-(const Float& f) const { binary_op(sub); }
    Float operator+(const Float& f) const { binary_op(add); }
    Float operator*(const Float& f) const { binary_op(mul); }
    Float operator/(const Float& f) const { binary_op(div); }
    
    #undef binary_op
    
    #define binary_opeq(opname) Float tmp; \
        mpfr_ ## opname (tmp.x, x, f.x, GMP_RNDD); \
        *this = tmp; \
        return *this;

    Float& operator+=(const Float& f) { binary_opeq(add); }
    Float& operator-=(const Float& f) { binary_opeq(sub); }
    Float& operator*=(const Float& f) { binary_opeq(mul); }
    Float& operator/=(const Float& f) { binary_opeq(div); }
    
    #undef binary_opeq

    bool operator>(const Float& f) const { return mpfr_cmp(x, f.x) > 0; }
    bool operator<(const Float& f) const { return mpfr_cmp(x, f.x) < 0; }
    bool operator==(const Float& f) const { return mpfr_cmp(x, f.x) == 0; }
    bool operator!=(const Float& f) const { return mpfr_cmp(x, f.x) != 0; }
    bool operator<=(const Float& f) const { return mpfr_cmp(x, f.x) <= 0; }
    bool operator>=(const Float& f) const { return mpfr_cmp(x, f.x) >= 0; }
    
    friend std::ostream& operator<<(std::ostream& o, const Float& f) {
        mp_exp_t e;
        char *s = mpfr_get_str(NULL, &e, 10, 0, f.x, GMP_RNDN);
        size_t l = strlen(s);
        while (s[l-1] == '0' && l >= 1) l--;
        s[l] = 0;
        char *t = s;
        if (s[0] == '-') {
            o << s[0]; t++;
        }
        if (*t == 0) {
            o << "0";
            free(s);
            return o;
        }
        if (e > 0) {
            o << *(t++); e--;
        }
        if (*t) o << "." << t;
        if (e != 0) o << 'e' << e;
        free(s);
        return o;
    }
    
    Float sqrt(const mp_rnd_t rnd = GMP_RNDD) const {
        Float f;
        mpfr_sqrt(f.x, x, rnd);
        return f;
    }
    
    Float abs(const mp_rnd_t rnd = GMP_RNDD) const {
        Float f;
        mpfr_abs(f.x, x, rnd);
        return f;
    }
    
    Float atan(const mp_rnd_t rnd = GMP_RNDD) const {
        Float f;
        mpfr_atan(f.x, x, rnd);
        return f;
    }

    Float tan(const mp_rnd_t rnd = GMP_RNDD) const {
        Float f;
        mpfr_tan(f.x, x, rnd);
        return f;
    }

    double to_double(mp_rnd_t rnd = GMP_RNDN) const { return mpfr_get_d(x, rnd); }
};


inline Float float_const_pi(const mp_rnd_t rnd = GMP_RNDD) {
    mpfr_t p;
    mpfr_init(p);
    mpfr_const_pi(p, rnd);
    return Float(p, rnd);
}
    

inline double to_double(const Float x, const mp_rnd_t rnd = GMP_RNDN) 
{ 
    return x.to_double(rnd); 
}

#endif
