/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _ELLIPSE_H_
#define _ELLIPSE_H_

#include "algebra.h"
#include "range.h"

#define ELLIPSE_PC(x) x.pc[0], x.pc[1], x.pc[2], x.pc[3], x.pc[4]
#define ELLIPSE_PCX(x) INTERVAL(x.pc[0]), INTERVAL(x.pc[1]), INTERVAL(x.pc[2]), INTERVAL(x.pc[3]), INTERVAL(x.pc[4])
//#define ELLIPSE_PCX(x) to_double(x.pc[0]), to_double(x.pc[1]), to_double(x.pc[2]), to_double(x.pc[3]), to_double(x.pc[4])

#define ELL_HASH_PRIME 2039

class Bitangent;

class Ellipse {
    QQ pc[5];   // parametric coeffs: a, b, w, xc, yc
    QQ ac[6];   // algebraic coeffs: a, b, c, d, e, f (remember 2b, 2d, 2e !)
    QQ J1, J2;  // invariants J1 = a+c, J2 = ac - b^2
    
    friend class EllipseTriplet;
    friend class VoronoiCircle;
    friend class Bitangent;
    friend class Bisector;
    friend class BisectorX;
    friend class ShortestDistance;

    friend int visible_arc_generic(const Ellipse e, IntF xe, IntF ye, RangeF &result);
    friend int visible_arc(const Ellipse &e1, const Ellipse &e2, const IntF t, RangeF& result);
    friend int apollonius_arc(const Ellipse &e1, const Ellipse &e2, const IntF t, const RangeF &vis, RangeF &result);
    friend int distance_from_bitangent(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict);
    friend int distance_from_bitangent_wbtan(const Ellipse &e1, const Ellipse &e2, const Ellipse &e3, int *conflict, 
                                      Bitangent &bt12, Bitangent &bt13);
//    friend int external_ccw_circle(Ellipse e1, Ellipse e2, Ellipse e3);

    int in_circle(Ellipse e1, Ellipse e2, Ellipse e3);
            
    void init_coeff(QQ a_, QQ b_, QQ w_, QQ xc_, QQ yc_);
    
    QQ eval_R(QQ x, QQ y) const;

public:
    Ellipse() { 
        pc[0] = 0; pc[1] = 0; pc[2] = 0; pc[3] = 0; pc[4] = 0;
        ac[0] = 0; ac[1] = 0; ac[2] = 0; ac[3] = 0; ac[4] = 0; ac[5] = 0;
        J1 = 0; J2 = 0;
    }

    Ellipse(const QQ a_, const QQ b_, const QQ w_, const QQ xc_, const QQ yc_) { 
        init_coeff(a_, b_, w_, xc_, yc_);
    }

    bool is_circle() const { return pc[0] == pc[1]; }
    
    QQ get_pc(const int i) const { return pc[i]; }

    QQ get_xc() const { return pc[3]; }
    
    QQ get_yc() const { return pc[4]; }
    
    QQ get_fake_weight() const { return pc[0]; }
    
    QQ get_alg_coeff(int i) const { return ac[i]; }
    
    QQ eval_eq(QQ x, QQ y) const {
        return ac[0]*x*x + ac[5] + ac[2]*y*y + 2*ac[4]*y + 2*(ac[3] + ac[1]*y)*x;
    }

    void translate(QQ x, QQ y) {
        pc[3] += x; pc[4] += y;
        init_coeff(pc[0], pc[1], pc[2], pc[3], pc[4]);
    }

    int ccw(QQ x1, QQ y1, QQ x2, QQ y2, Root t) const;
    
    int hash() const;
    
    void print_eq(std::ostream& o);
    friend std::ostream& operator<<(std::ostream& o, const Ellipse& x);
    friend std::istream& operator>>(std::istream& i, Ellipse& x);
    bool operator==(const Ellipse &x) const;
    
    // predicate k1
    friend QQ ell_eval_R(Ellipse e1, QQ x, QQ y);
    friend upolz_t ell_distance_poly(Ellipse e1, QQ v1, QQ v2);
};

#endif
