/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"
#include "parnorm.h"
#include "ellipse.h"
#include "bitangent.h"
#include "bisectorx.h"

upolz_t parnorm_CC(QQ xc1, QQ yc1, QQ xc2, QQ yc2)
{
    upolq_t res(3, AsSize());
    
    res[2] = yc1-yc2;
    res[1] = 2*(xc1-xc2);
    res[0] = -res[2];
    
    return primpart(res);
}

upolz_t parnorm(QQ a1, QQ b1, QQ w1, QQ xc1, QQ yc1, 
        QQ a2, QQ b2, QQ w2, QQ xc2, QQ yc2)
{
    if (a1 == b1 && a2 == b2) return parnorm_CC(xc1, yc1, xc2, yc2);

    // computes determinant of Sylvester matrix
    QQ t36, t67, t73, t49, t35, t59, t72, t71, t70, t69, t60, t52, t66, t68,
             t57, t64, t58, t55, t54, t53, t47, t46, t45, t44, t43, t42, t41, t40,
             t39, t6, t5, t4, t3, t2, t1;
    QQ poly1[3], poly2[3], poly3[5], poly4[5], poly5[5];

    t36 = w2*w2;
    t67 = -t36-1;
    t73 = 4*w1*w2;
    t49 = t67*yc1;
    t35 = w1*w1;
    t59 = t35*t36;
    t72 = 1+t59;
    t71 = t67*yc2;
    t70 = -t35-t36;
    t69 = (1+t35)*a1*a1;
    t60 = a1*t35;
    t52 = a1*t59;
    t66 = (-t60+t52+(1-t36+t73)*a1)*a2;
    t68 = (xc1+(-2*yc2+2*yc1)*w1)*a1;
    t57 = xc2-xc1;
    t64 = a2*w2;
    t58 = 2*t57;
    t55 = -2*t64;
    t54 = 2*t64;
    t53 = 2*t36;
    t47 = (t35*t49+t71)*b1;
    t46 = -t35*w2-w1+w1*t36+w2;
    t45 = t73+t70+t72;
    t44 = t69*t36+(t70-t72)*b1*b1+t69;
    t43 = a1*t46;
    t42 = t45*b1;
    t41 = xc2*t52+(xc2+t35*xc1)*t67*a1+xc2*t60+t68*t36+t68;
    t40 = t41+t44;
    t39 = t41-t44;
    t6 = t46*b2*b1;
    t5 = b2*t42;
    t4 = a2*t42;
    t3 = 16*b2*t43;
    t2 = (t55+(t54-t71)*t35+(2*a2+(-a2+t57)*t53+t58)*w1-t49)*b1+t47;
    t1 = (t54+(t55-t71)*t35+(-2*a2+(a2+t57)*t53+t58)*w1-t49)*b1+t47;
    poly1[0] = -8*t6;
    poly1[1] = 8*t45*b2*a1;
    poly1[2] = 8*t6;
    
    poly2[0] = 8*t4;
    poly2[1] = 32*a2*t43;
    poly2[2] = -8*t4;
    
    poly3[0] = -2*t1;
    poly3[1] = 4*t40+4*t66;
    poly3[2] = 0;
    poly3[3] = 4*t39+4*t66;
    poly3[4] = 2*t1;
    
    poly4[0] = 4*t5;
    poly4[1] = t3;
    poly4[2] = 0;
    poly4[3] = t3;
    poly4[4] = -4*t5;
    
    poly5[0] = -2*t2;
    poly5[1] = 4*t40-4*t66;
    poly5[2] = 0;
    poly5[3] = 4*t39-4*t66;
    poly5[4] = 2*t2;
    
    upolq_t p1(3, poly1);
    upolq_t p2(3, poly2);
    upolq_t p3(5, poly3);
    upolq_t p4(5, poly4);
    upolq_t p5(5, poly5);
    
    upolz_t res = primpart((p3*p5*p2+(p3-p5)*p4*p1)*p2+(p5*p5-p4*p4+(2*p5+p3)*p3)*p1*p1);
    
    if (a1 == b1) {
        upolz_t t2p1("x^4+2*x^2+1");
        res = quo(res, t2p1);
    }
    
    return res;

/*    return (p1*p1*p5*p5) - (p1*p4*p2*p5) - (p1*p1*p4*p4) + (2*p3*p1*p1*p5) + 
           (p3*p2*p2*p5) + (p3*p2*p1*p4) + (p3*p3*p1*p1);*/
}


ShortestDistance::ShortestDistance(const Ellipse &e1, const Ellipse &e2): e1_(e1), e2_(e2) 
{
    p12 = parnorm(ELLIPSE_PC(e1_), ELLIPSE_PC(e2_));
    p21 = parnorm(ELLIPSE_PC(e2_), ELLIPSE_PC(e1_));
    Bitangent bt12(e1_, e2_);
    Bitangent bt21(e2_, e1_);
    trange = VORELL::Range<Root>(bt12.get_sol(bt12.get_external()), bt12.get_sol(bt12.get_other_external()));
//    rrange = VORELL::Range<Root>(bt21.get_sol(bt12.get_external()), bt21.get_sol(bt21.get_other_external()));
    
    RootSeq sol1 = AK::solve(p12);
    RootSeq sol2 = AK::solve(p21);
    Float mindist, dist;
    int ii = -1, jj;
    IntF t, r, dx, dy;
    for (unsigned int i = 0; i < sol1.size(); i++)
        for (unsigned int j = 0; j < sol2.size(); j++)
            if (bt12.is_between(sol1[i]) && bt21.is_between(sol2[j])) {
                t = INTERVAL(sol1[i]);
                r = INTERVAL(sol2[j]);
                dx = (ellipse_x(ELLIPSE_PCX(e1_), t)-ellipse_x(ELLIPSE_PCX(e2_), r));
                dy = (ellipse_y(ELLIPSE_PCX(e1_), t)-ellipse_y(ELLIPSE_PCX(e2_), r));
                dist = IntF(sqr(dx) + sqr(dy)).upper();
//                std::cerr << "t = " << t << std::endl;
//                std::cerr << "r = " << r << std::endl;
//                std::cerr << "dist = " << dist << std::endl;
                if (ii == -1 || dist < mindist) {
                    mindist = dist;
                    ii = i; jj = j;
                }
            }
    tsol = sol1[ii];
    rsol = sol2[jj];
}
