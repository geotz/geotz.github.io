/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _PARNORM_H_
#define _PARNORM_H_

#include "algebra.h"
#include "ellipse.h"
#include "range.h"

using namespace mmx;

upolz_t parnorm(QQ a1, QQ b1, QQ w1, QQ xc1, QQ yc1, 
        QQ a2, QQ b2, QQ w2, QQ xc2, QQ yc2);

class ShortestDistance {
    
    Ellipse e1_, e2_;
    upolz_t p12, p21;
    Root tsol, rsol;

    VORELL::Range<Root> trange;
//    VORELL::Range<Root> rrange;
    
public:
    
    ShortestDistance(const Ellipse &e1, const Ellipse &e2);
    
    Root get_tsol() const { return tsol; }
    Root get_rsol() const { return rsol; }
    
    const VORELL::Range<Root>& get_trange() const { return trange; }
//    const VORELL::Range<Root>& get_rrange() const { return rrange; }
    
};

#endif
