/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#include "algebra.h"
#include "ellipse.h"
#include "bitangent.h"
#include "range.h"
#include "bisectorx.h"
#include "incircle.h"

//#include <subdivix/sleeve_approx.hpp>
IntF ellipse_x(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, const IntF t)
{
    IntF t1, t2, t3, t4;
    t4 = -a+xc;
    t3 = a+xc;
    t2 = t*t;
    t1 = w*w;
    return IntF(-4*b*w*t+t4*t2+IntF(t3*t2+t4)*t1+t3)/IntF(IntF(1+t1)*IntF(1+t2));
}


IntF ellipse_y(const IntF a, const IntF b, const IntF w, const IntF xc, const IntF yc, const IntF t)
{
    IntF t1, t2, t3, t4, t5;
    t2 = t*t;
    t5 = 1+t2;
    t4 = b*t;
    t3 = t5*yc;
    t1 = w*w;
    return -IntF(-2*t4+IntF(2*t2-2)*w*a+IntF(2*t4-t3)*t1-t3)/IntF(IntF(1+t1)*t5);
}


int sign_vis_det(const IntF x, const IntF y, const IntF a, const IntF b, const IntF w, 
        const IntF xc, const IntF yc, const upoli_t &tanpoly)
{
    IntF t1,t2,t3,t4,t5,t6,t7, res;
    t6 = -1*yc+y;
    t2 = 2*w;
    t7 = t6*t2;
    t5 = x-xc;
    t4 = -1*a-t5;
    t3 = -1*a+t5;
    t1 = w*w;
    res = (t5*t2+t6*t1-t6)*tanpoly[1]*a+((t7+t4*t1+t3)*tanpoly[2]+(-1*t7+t3*t1+t4)*tanpoly[0])*b;
//    assert ( res != 0 );
//    if ( res == 0 ) throw Exception(Exception::ZERO);
    return Sign(res);
}

/* returns 0 on succes, -1 on failure */
int visible_arc_generic(const Ellipse e, IntF xe, IntF ye, RangeF &result) 
{
    upoli_t tanp = tan_poly_xy(ELLIPSE_PCX(e), xe, ye);
    int status;
    std::pair<IntF,IntF> rr = TrinomialSolver(tanp, status);
    if (status != 2) return -1;

    IntF midr = -tanp[1] / (2*tanp[2]);

    // ***** line r1 r2 (Determinant sign) (CCWs) ******
    int Lrr = sign_vis_det(xe, ye, ELLIPSE_PCX(e), tanp) *
           sign_vis_det(ellipse_x(ELLIPSE_PCX(e), midr), ellipse_y(ELLIPSE_PCX(e), midr), ELLIPSE_PCX(e), tanp);

    if (Lrr > 0) {
        result = RangeF(rr.first, rr.second);
        return 0;
    } else {
//        from x,y visible arc of e contains i-point
        result = RangeF(rr.second, rr.first);
        return 0;
    }
}

inline int visible_arc(const Ellipse &e1, const Ellipse &e2, const IntF t, RangeF &result) 
{
    return visible_arc_generic(e2, ellipse_x(ELLIPSE_PCX(e1), t), ellipse_y(ELLIPSE_PCX(e1), t), result);
}

/* 
  returns 0 on succes, 
  -1 on failure
*/
int apollonius_arc(const Ellipse &e1, const Ellipse &e2, const IntF t, const RangeF &vis, RangeF &result)
{
    upoli_t tcut = tan_poly_cut(ELLIPSE_PCX(e1), ELLIPSE_PCX(e2), t);
    
    int status;
    std::pair<IntF,IntF> rr = TrinomialSolver(tcut, status);
    if (status == 0) {
        result = vis; // Visible arc is Apollonius arc
        return 0;
    }
    if (status != 2) return -1;

    IntF Ept, Qpt;
    // TODO: Qpt is an interval, check degenerate cases
    
    // TODO: rr is an interval... is it contained in whole?
    if (vis.contains(rr.first)) Qpt = rr.first; else Qpt = rr.second;
//    std::cerr << "Qpt = " << Qpt << std::endl;
    
    // TODO: s1 is always positive?
    int s1 = tan_poly_sign(ELLIPSE_PCX(e1), INTERVAL(e1.pc[3]), INTERVAL(e1.pc[4]), t);
    int s2 = tan_poly_sign(ELLIPSE_PCX(e1), ellipse_x(ELLIPSE_PCX(e2), vis.a), ellipse_y(ELLIPSE_PCX(e2), vis.a), t);
    
//    std::cerr << "s1 s2 = " << s1 << ' ' << s2 << std::endl;

    if (s1*s2 > 0) Ept = vis.b; else Ept = vis.a;
    // endpoint chosen

    // TODO: can be optimized ?
    if (vis.is_finite()) {          // no ipt
        if (Qpt > Ept) result = RangeF(Ept, Qpt);
        else result = RangeF(Qpt, Ept);
    } else {
        if (Qpt < vis.b) {
            if (Ept == vis.a) result = RangeF(Ept, Qpt);
            else result = RangeF(Qpt, Ept);
        } else {
            if (Ept == vis.b) result = RangeF(Qpt, Ept);
            else result = RangeF(Ept, Qpt);
        }
    }
    return 0;
}

IntF ell_bisector_CC_solve(IntF a1, IntF xc1, IntF yc1, IntF a2, IntF xc2, IntF yc2, IntF t)
{
    IntF dy = yc2 - yc1;
    IntF dx = xc2 - xc1;
    IntF dr = a2 - a1;
    
    return -IntF(dy*t + dx + dr) / IntF((dr - dx)*t + dy);
}


IntF BisectorX::solve(const IntF t)
{
    if (e1_.is_circle() &&  e2_.is_circle()) {
        status = 1;
        return ell_bisector_CC_solve(INTERVAL(e1_.pc[0]), INTERVAL(e1_.pc[3]), INTERVAL(e1_.pc[4]), 
                                     INTERVAL(e2_.pc[0]), INTERVAL(e2_.pc[3]), INTERVAL(e2_.pc[4]), t);
    }
    
    if (visible_arc(e1_, e2_, t, last_visible_arc) < 0) {
        if (certified) {
            std::cerr << "visible arc failed" << std::endl;
            abort();
        }
#ifdef VERBOSE
        std::cerr << "visible arc failed, but certified computation not requested" << std::endl;
#endif
        status = -3;
        return IntF(0);
    }
    
    if (apollonius_arc(e1_, e2_, t, last_visible_arc, last_apollonius_arc) < 0) {
        if (certified) {
            std::cerr << "apollonius arc failed" << std::endl;
            abort();
        }
#ifdef VERBOSE
        std::cerr << "apollonius arc failed, but certified computation not requested" << std::endl;
#endif
        status = -4;
        return IntF(0);
    }
    IntF sol;
    int status1 = -10;
    int status2 = -10;
    
//    std::cerr << "vis = " << last_visible_arc << std::endl;
//    std::cerr << "apoll = " << last_apollonius_arc << std::endl;
    
    upoli_t p = polyx(t);
    if (last_apollonius_arc.is_finite()) {
        sol = IntervalSolver(p, diff2(p), INTERVAL(last_apollonius_arc.a, last_apollonius_arc.b), 0, status1);
        if (status1 != 1) {
            std::cerr << "t = " << t << ": no unique sol for " << p << " in " << last_apollonius_arc << std::endl;
            std::cerr << "status = " << status1 << std::endl;
            if (certified) abort(); else std::cerr << "but certified computation not requested" << std::endl;
        }
        status = status1;
        return sol;
    } else {
        Float cb = cauchy_bound(p);
        assert (cb > last_apollonius_arc.a || (-cb) < last_apollonius_arc.b);
        if (cb > last_apollonius_arc.a) {
            sol = IntervalSolver(p, diff2(p), INTERVAL(last_apollonius_arc.a, cb), 0, status1);
            /*if (status1 != 1) {
                std::cerr<< "apoll = " << last_apollonius_arc << std::endl;
                std::cerr << "t = " << t << ": no unique sol for " << p << " in " << INTERVAL(last_apollonius_arc.a,cb) << std::endl;
                std::cerr << "status1 = " << status1 << std::endl;
            }*/
            status = status1;
            if (status1 == 1) return sol;
        }
        if ((-cb) < last_apollonius_arc.b) {
            sol = IntervalSolver(p, diff2(p), INTERVAL(-cb, last_apollonius_arc.b), 0, status2);
            if (status2 != 1) {
                std::cerr<< "apoll = " << last_apollonius_arc << std::endl;
                std::cerr << "t = " << t << ": no unique sol for " << p << " in " << INTERVAL(-cb,last_apollonius_arc.b) << std::endl;
                std::cerr << "status2 = " << status2 << std::endl;
                std::cerr << "status1 = " << status1 << std::endl;
                if (certified) abort(); else std::cerr << "but certified computation not requested" << std::endl;
            }
            status = status2;
            return sol;
        }
        assert(false);
    }
}

/* 
   cstatus = 0:  OK
            -2:  denom. is zero
*/
void BisectorX::get_coords(const IntF t, IntF r, IntF& x, IntF& y, int& cstatus)
{
    IntF t15, t11, t94, t118, t10, t122, t12, t8, t97, t101, t66, t9, t77, 
           t110, t128, t90, t6, t72, t47, t123, t85, t23, t126, t89, t124,
           t96, t109, t75, t105, t88, t104, t7, t92, t51, t86, t84, t79,
           t71, t69, t68, t67, t65, t64, t59, t58, t57, t42, t20, t1;
    
    IntF a1, b1, w1, xc1, yc1;
    IntF a2, b2, w2, xc2, yc2;
    
    cstatus = 0;
    
    a1 = INTERVAL(e1_.pc[0]); b1 = INTERVAL(e1_.pc[1]); w1 = INTERVAL(e1_.pc[2]); 
    xc1 = INTERVAL(e1_.pc[3]); yc1 = INTERVAL(e1_.pc[4]);
    a2 = INTERVAL(e2_.pc[0]); b2 = INTERVAL(e2_.pc[1]); w2 = INTERVAL(e2_.pc[2]); 
    xc2 = INTERVAL(e2_.pc[3]); yc2 = INTERVAL(e2_.pc[4]);

    t15 = t*t;
    t11 = t15*t15;
    t94 = -t11+1;
    t118 = b1*t94;
    t10 = t15*t;
    t122 = (b1*b1-a1*a1)*(-t10+t);
    t12 = r*r;
    t8 = t12*t12;
    t97 = t8-1;
    t101 = b2*t97;
    t66 = -yc2+yc1;
    t9 = r*t12;
    t77 = t9+r;
    t110 = t77*w2;
    t128 = t66*t110;
    t90 = xc2-xc1;
    t6 = w2*w2;
    t72 = -t6+1;
    t47 = (t8-t8*t6-t72)*yc2;
    t123 = (-t9+r)*(-b2*b2+a2*a2);
    t85 = -2*t6;
    t23 = (-2+t85)*t123;
    t126 = -t23+(t47-t90*w2*(2*t8-2))*b2;
    t89 = t77*a2;
    t124 = w2*t101;
    t96 = -t10-t;
    t109 = t96*a1;
    t75 = 2+t85;
    t105 = t90*t75;
    t88 = xc2*t77;
    t104 = t75*t88;
    t7 = w1*w1;
    t92 = t75*t7;
    t51 = t92+t75;
    t86 = t96*t77;
    t84 = 2*xc1;
    t79 = -4+4*t6;
    t71 = a2*w2;
    t69 = w2*xc2;
    t68 = yc2*w2;
    t67 = w1*yc1;
    t65 = -4*t68;
    t64 = w1*t84;
    t59 = -2*xc2+4*t67+t84;
    t58 = t64-t66;
    t57 = -2*t69-t66;
    t42 = -4*t67+2*t90;
    t20 = (4*t68+t105)*t89+t126;
    t1 = ((w2-t7*w2+t6*w1-w1)*t101*t118+(-t89*t118+t101*t109)*(4*w2*w1+t7
         *t6-t7+t72)+(w1*t79-w2*(-4+4*t7))*a2*a1*t86);
    if (isign(t1) == 0) {
        cstatus = -2;
        return;
    }

    IntF tx1 = (IntF(INTERVAL(-1)*IntF(8*t7-8)*t71*t86-t96*IntF(t92-t75)*t101)*xc1-t96*IntF(IntF(IntF((8)-8*t6)*
    t88-16*t128)*a2+((8-8*t8)*t69+t97*t66*t79)*b2+(8*t6+8)*t123)*w1);
    
    IntF tx2 = IntF(-IntF(-t23+(t104-4*t128)*a2-(-t66*t6-t57)*t101)*t7-t23+(-t58*t6+t64+t57)*t101+IntF(
    t104+4*t58*t110)*a2);
    
    x = (tx1*a1-tx2*t118+(INTERVAL(-1)*t77*t71*(-8-8*t7)+t51*t101)*t122)/(INTERVAL(2)*t1);
    
    y = ((((-t7+t7*t11+t94)*t124+(t7-1)*t72*t94*t89)*yc1+((t65-t105)*t89+
    t20*t11-t126)*w1)*b1-((-t47+(t8*t42+t59)*w2)*b2+(t65+t6*t42+t59)*t89+t20*t7+t23
    )*t109-((-2-2*t7)*t124+t89*t51)*t122)/t1;
}

/* 
   cstatus = 0:  OK
            -1:  B(t,r) no unique sol.
            -2:  denom. is zero
*/
void BisectorX::get_coords(const IntF t, IntF& x, IntF& y, int& cstatus)
{
    IntF r = solve(t);
    if (status != 1) {
        cstatus = -1;
        return;
    }
    get_coords(t, r, x, y, cstatus);
}

//get squared radius of bitangent circle
void BisectorX::get_radius2(const IntF t, const IntF xc, const IntF yc, IntF &radius2)
{
    IntF x1 = ellipse_x(ELLIPSE_PCX(e1_), t);
    IntF y1 = ellipse_y(ELLIPSE_PCX(e1_), t);
    
    radius2 = sqr(xc-x1) + sqr(yc-y1);
}

void BisectorCurve::add_point(Float p) 
{
    IntF x, y;
    Float px, py;
    Float t = p.tan();
    int cs;
    bx12.get_coords(t, x, y, cs);
    if (cs == 0) {
        px = x; py = y;
        xx.push_back(to_double(px));
        yy.push_back(to_double(py));
//                  std::cerr << "x = " << x << " y = " << y << " " << px << " " << py << std::endl;
    }// else std::cerr << "invalid point (" << cs << ")\n";
}

const int BisectorCurve::res = 200;
const double BisectorCurve::near = 0.1;
const double BisectorCurve::magnify = 16;

void BisectorCurve::generate_points() 
{
    Float p1 = trange.a.atan(GMP_RNDU);
    Float p2 = trange.b.atan(GMP_RNDD);
//    std::cerr << "p1p2 = " << p1 << "," << p2 << "\n";

    Float step = float_const_pi() / Float(res);
    Float st;
    Float nr = Float(near);
//        std::cerr << "step = " << step << std::endl;

    if (p1 < p2) {
        Float p = p1;
        bool last = false;
        do {
            if (p - p1 < nr || p2 - p < nr) st = step / Float(magnify);
            else st = step;
            add_point(p);
            p += st;
            if (p > p2 && !last) {
                p = p2;
                last = true;
            }
        } while (p < p2);
    } else {
        Float pi_2 = float_const_pi() / Float(2);
        Float p, pf;
        pf = pi_2 - step;
        p = p1;
        do {
            if (p - p1 < nr || pf - p < Float(near)) st = step / Float(magnify);
            else st = step;
            add_point(p);
            p += st;
        } while (p < pf);
        pf = -pi_2+step;
        p = pf;
        bool last = false;
        do {
            if (p - pf < nr || p2 - p < nr) st = step / Float(magnify);
            else st = step;
            add_point(p);
            p += st;
            if (p > p2 && !last) {
                p = p2;
                last = true;
            }
        } while (p < p2);
    }
    std::cerr << "BisectorCurve: generated " << xx.size() << " points" << std::endl;
}

BisectorCurve::BisectorCurve(const Ellipse& e1, const Ellipse& e2): 
        e1_(e1), e2_(e2)
{
    nell = 2;
    if (cache.load(*this)) return;

    bx12 = BisectorX(e1, e2, false);
    Bitangent bt12(e1, e2);
    trange = RANGE_in(bt12.chrange());
//    std::cerr << "BisectorCurve(" << trange << ")\n";

    generate_points();
    cache.update(*this);
}

BisectorCurve::BisectorCurve(const Ellipse& e1, const Ellipse& e2, const Ellipse &e3): 
        e1_(e1), e2_(e2), e3_(e3)
{
    nell = 3;
    if (cache.load(*this)) return;

    bx12 = BisectorX(e1, e2, false);
    Bitangent bt12(e1, e2);
    trange = RANGE_in(bt12.chrange());
//    std::cerr << "BisectorCurve(" << trange << ")/RAY\n";

    VoronoiCircle vpqr = EllipseTriplet(e1, e2, e3).voronoi_circle();
    trange = RangeF(trange.a, vpqr.get_solx(0).upper());

    generate_points();
    cache.update(*this);
}

BisectorCurve::BisectorCurve(const Ellipse& e1, const Ellipse& e2, const Ellipse &e3, const Ellipse &e4): 
        e1_(e1), e2_(e2), e3_(e3), e4_(e4)
{
    nell = 4;
    if (cache.load(*this)) return;

    bx12 = BisectorX(e1, e2, false);
    Bitangent bt12(e1, e2);
    trange = RANGE_in(bt12.chrange());
//    std::cerr << "BisectorCurve(" << trange << ")/SEGMENT\n";

    VoronoiCircle vpsq = EllipseTriplet(e1, e4, e2).voronoi_circle();
    VoronoiCircle vpqr = EllipseTriplet(e1, e2, e3).voronoi_circle();
    trange = RangeF(vpsq.get_solx(0).lower(), vpqr.get_solx(0).upper());

    generate_points();
    cache.update(*this);
}

bool BisectorCurve::operator==(const BisectorCurve &x) const 
{
    if (nell != x.nell) return false;
    switch (nell) {
        case 2: return e1_ == x.e1_ && e2_ == x.e2_;
        case 3: return e1_ == x.e1_ && e2_ == x.e2_ && e3_ == x.e3_;
        case 4: return e1_ == x.e1_ && e2_ == x.e2_ && e3_ == x.e3_ && e4_ == x.e4_;
        default: return false;
    }
}

size_t BisectorCurve::hash() const 
{
    switch(nell) {
        case 2: return (e1_.hash() + e2_.hash()) % ELL_HASH_PRIME;
        case 3: return (e1_.hash() + e2_.hash() + e3_.hash()) % ELL_HASH_PRIME;
        case 4: return (e1_.hash() + e2_.hash() + e3_.hash() + e4_.hash()) % ELL_HASH_PRIME;
        default: return 0;
    }
}
