/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef _ISOLVER_H
#define _ISOLVER_H

#include "float.h"
#include <algebrix/upoldse.hpp>
#include <algebrix/Interval.hpp>

#include "exception.h"

typedef Interval<Float> IntF;
typedef upoldse<IntF> upoli_t;
typedef mpoldst<IntF> mpoli_t;
typedef monomial<IntF> monomi_t;

#include "range.h"
typedef VORELL::Range<Float> RangeF;

template<typename T>
inline IntF INTERVAL(T x) { return IntF(Float(x, GMP_RNDD), Float(x, GMP_RNDU)); }

template<typename Ta, typename Tb>
inline IntF INTERVAL(Ta x, Tb y) { return IntF(Float(x, GMP_RNDD), Float(y, GMP_RNDU)); }

//#define INTERVAL(x) IntF(Float((x), GMP_RNDD), Float((x), GMP_RNDU))
//#define INTERVAL2(x,y) IntF(Float((x), GMP_RNDD), Float((y), GMP_RNDU))

inline IntF operator-(const int a, const IntF& f) { return INTERVAL(a)-f; }
inline IntF operator+(const int a, const IntF& f) { return INTERVAL(a)+f; }
inline IntF operator*(const int a, const IntF& f) { return INTERVAL(a)*f; }
inline IntF operator-(const IntF& f) { return INTERVAL(-1)*f; } 

inline IntF operator-(const IntF& f, const int a) { return f - INTERVAL(a); }
inline IntF operator+(const IntF& f, const int a) { return f + INTERVAL(a); }
inline IntF operator*(const IntF& f, const int a) { return f * INTERVAL(a); }

inline int isign(const IntF& x)
{
    if (x.upper() < 0) return -1;
    if (x.lower() > 0) return 1;
    return 0;
}

inline int Sign(const IntF& x)
{
    if (x.upper() < 0) return -1;
    if (x.lower() > 0) return 1;
    std::cerr << "Sign: interval contains zero!\n";
    abort();
}


inline Float maxabs(const IntF& x)
{
    return std::max(x.lower().abs(), x.upper().abs());
}

inline IntF sqrt(IntF x)
{
//    assert ( x.upper() >= 0 );
    if (x.upper() < 0) throw Exception(Exception::BADSQRT, "sqrt()");
    if (x.lower() > 0)
        return IntF(x.lower().sqrt(), x.upper().sqrt(GMP_RNDU));
    return IntF(0, x.upper().sqrt(GMP_RNDU));
}

inline IntF sqr(IntF x)
{
    if (x.upper() > 0 || x.lower() < 0) return x*x;
    return IntF(Float(0), maxabs(x));
}


/*template <class R> Float CauchyBound(const R &p)
{
    assert ( isign(lcoeff(p)) != 0 );
    int d = degree(p);
    if (d == 0) return maxabs(IntF(p[0]));
    Float m = maxabs(IntF(p[d-1]));
    for (int i = d-2; i >= 0; i--) if (maxabs(IntF(p[i])) > m) m = maxabs(IntF(p[i]));
    m += maxabs(IntF(p[d]));
    return IntF(IntF(m) / IntF(maxabs(IntF(p[d])))).upper();
}*/

template <class R> IntF IntervalNewton(const R &p, const R &dp, const IntF approx)
{
    Float x = approx;
    return IntF(IntF(x) - IntF(p(IntF(x))/dp(approx)));
} 

template <class R> IntF IntervalBisect(const R &p, const IntF approx, int &status)
{
    Float x = approx;
    IntF lval, rval, mval;
    lval = p(approx.lower());
    rval = p(approx.upper());
    mval = p(x);
//    std::cerr << lval << ' ' << rval << ' ' << mval << ' ' << x << std::endl;
//    assert( isign(lval)*isign(rval) <= 0 );
    if (isign(lval)*isign(rval) > 0) {
        status = -1;
        return approx;
    }
    
    status = 0;
    if (mval == 0) return IntF(x);
    if (lval == 0) return IntF(approx.lower()); 
    if (rval == 0) return IntF(approx.upper());
    if (isign(lval) == isign(mval)) return IntF(x,approx.upper());
    return IntF(approx.lower(), x);
}

/*
status:
-2 = no root exists
-1 = no root found
0 = root found
1 = unique root found
*/

// caution of coeffs including zero !
template <class R> IntF IntervalSolver(const R &p, const R &dp, IntF approx, Float delta, int &status)
{
    IntF slope, testapprox, newapprox, ver;
    Float oldw = approx.width(), neww;
    int z;
//    int i = 0;
    
    status = 0;
    slope = dp(approx);
//    std::cerr << "slope = " << slope << slope.width() << std::endl;
    z = isign(slope);
    if (isign(p(approx.lower())) * isign(p(approx.upper())) > 0) {
        if (z == 0) status = -1; else status = -2;
        return approx;
    }
    assert(isign(p(approx)) == 0);
//    std::cerr << "solving " << p << std::endl;
//    std::cerr << "bound = " << CauchyBound(p) << std::endl;

    while (1) {
        if (oldw >= 1 || z == 0) {
            approx = IntervalBisect(p, approx, status);
            if (status < 0) return approx;
            neww = approx.width();
//            std::cerr << '(' << (++i) << ") Bisect: " << approx << ' ' << neww << std::endl;
            if (neww < delta) break;
//            assert(neww < oldw);
            if (neww >= oldw) throw Exception(Exception::NOCONVERGE, "IntervalSolver/Bisect");
            oldw = neww;
        } else {
//            std::cerr << "slope = " << slope << std::endl;
            testapprox = IntervalNewton(p, dp, approx);
            if (intersect(newapprox, testapprox, approx)) {
//                std::cerr <<"new =" << newapprox << " test = " << testapprox << " old = " << approx << std::endl;
                ver = p(newapprox);
                if (ver != IntF(0)) {
//                  assert (isign(ver.lower()) < 0 && isign(ver.upper()) > 0);
                    // BUG: can this happen?
                    if (isign(ver) != 0) throw Exception(Exception::NOCONVERGE, "IntervalSolver/Newton");
                }
                neww = newapprox.width();
//                std::cerr << '(' << (++i) << ") Newton: " << newapprox << ' ' << neww << std::endl;
                if (Float(2)*neww >= oldw) break;
                approx = newapprox;
                if (neww < delta) break;
                oldw = neww;
            } else {
                throw Exception(Exception::NOCONVERGE, "Intersection/Newton");
            }
        }
        slope = dp(approx);
//        std::cerr << "slope = " << slope << slope.width() << std::endl;
        z = isign(slope);
    }
    if (isign(dp(approx)) != 0) status = 1;
    return approx;
}

IntF INTERVAL(const Root &r);

inline RangeF RANGE(const VORELL::Range<Root> &r) { return RangeF(INTERVAL(r.a).lower(), INTERVAL(r.b).upper()); }
inline RangeF RANGE_in(const VORELL::Range<Root> &r) { return RangeF(INTERVAL(r.a).upper(), INTERVAL(r.b).lower()); }

IntF mpol_eval(const mpoli_t p, const std::vector<IntF>& v);

extern template IntF IntervalNewton<upoli_t>(const upoli_t &p, const upoli_t &dp, IntF approx);
extern template IntF IntervalBisect<upoli_t>(const upoli_t &p, IntF approx, int &status);
extern template IntF IntervalSolver<upoli_t>(const upoli_t &p, const upoli_t &dp, IntF approx, Float delta, int &status);

#endif
