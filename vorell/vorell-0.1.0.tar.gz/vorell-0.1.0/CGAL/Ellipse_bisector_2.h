/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef CGAL_ELLIPSE_BISECTOR_2_H
#define CGAL_ELLIPSE_BISECTOR_2_H

#include <CGAL/enum.h>

#include <CGAL/Apollonius_site_2.h>
#include <CGAL/Kernel_traits.h>

#include "ellipses/bisectorx.h"
#include "ellipses/bitangent.h"

CGAL_BEGIN_NAMESPACE

template < class Gt >
class Ellipse_bisector_2
{
public:
  typedef Gt                Geom_traits;
  typedef typename Gt::Site_2     Site_2;
  
  typedef Simple_cartesian<double> Vk;
  
  typedef Segment_2<Vk >  Segment_2;
  typedef Point_2<Vk >    Point_2;
  typedef Vk::FT         FT;
  

protected:

  BisectorCurve bc12;

public:
  Ellipse_bisector_2()  { }

  Ellipse_bisector_2(const Site_2 &e1, const Site_2 &e2)
  {
      bc12 = BisectorCurve(e1, e2);
  }

  // ray
  Ellipse_bisector_2(const Site_2 &p, const Site_2 &q, const Site_2 &r) 
  {
      bc12 = BisectorCurve(p, q, r);
  }

  // segment
  Ellipse_bisector_2(const Site_2 &p, const Site_2 &q, const Site_2 &r, const Site_2 &s) 
  {
      bc12 = BisectorCurve(p, q, r, s);
  }
  
/*#if defined CGAL_USE_QT

  template<class QTWIDGET>
  void draw_qt(QTWIDGET& W)
    {
      
      std::vector< Point_2 > pseq;
      generate_points(pseq);

      for (unsigned int i = 0; i < pseq.size() - 1; i++) {
	W << Segment_2(pseq[i], pseq[i+1]);
      }
      
    }
#endif*/

  template< class Stream >
  void draw(Stream &W)
  {
/*    for (unsigned int i = 0; i < bc12.xx.size(); i++) {
        Point_2 p(bc12.xx[i], bc12.yy[i]);
        W << p;
    }*/
    if (bc12.xx.size() > 1) for (unsigned int i = 0; i < bc12.xx.size()-1; i++) {
        Point_2 p1(bc12.xx[i], bc12.yy[i]);
        Point_2 p2(bc12.xx[i+1], bc12.yy[i+1]);
        W << Segment_2(p1, p2);
    }
      
  }

};

template< class Stream, class Gt >
inline
Stream& operator<<(Stream& s, const Ellipse_bisector_2<Gt> &H)
{
  H.draw(s);
  return s;
}


CGAL_END_NAMESPACE

#endif
