// Copyright (c) 2003,2004  INRIA Sophia-Antipolis (France).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you may redistribute it under
// the terms of the Q Public License version 1.0.
// See the file LICENSE.QPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $URL: svn+ssh://scm.gforge.inria.fr/svn/cgal/branches/CGAL-3.3-branch/Apollonius_graph_2/include/CGAL/Parabola_segment_2.h $
// $Id: Parabola_segment_2.h 30902 2006-05-02 11:28:46Z mkaravel $
// 
//
// Author(s)     : Menelaos Karavelas <mkaravel@cse.nd.edu>

// Modified by George M. Tzoumas for the Voronoi Diagram of Ellipses


#ifndef CGAL_PARABOLA_SEGMENT_2_H
#define CGAL_PARABOLA_SEGMENT_2_H

#include <CGAL/Parabola_2.h>

CGAL_BEGIN_NAMESPACE

template < class Gt >
class Parabola_segment_2 : public Parabola_2< Gt >
{
  typedef CGAL::Parabola_2<Gt>            Base;
  typedef typename Base::Site_2           Site_2;
/*  typedef typename Base::FT               FT;
  typedef typename Base::Point_2          Point_2;
  typedef typename Base::Segment_2        Segment_2;
  typedef typename Base::Line_2           Line_2;*/

  typedef Simple_cartesian<double> Vk;
  typedef Point_2<Vk>                  Point_2;
  typedef Line_2<Vk>                   Line_2;
  typedef Segment_2<Vk>                Segment_2;
  typedef Vk::FT                       FT;

protected:
  Point_2 p1, p2;

public:
  Parabola_segment_2() : Parabola_2< Gt >() {}

  template<class ApolloniusSite>
  Parabola_segment_2(const ApolloniusSite &p, const typename Gt::Line_2 &l,
		     const typename Gt::Point_2 &p1, const typename Gt::Point_2 &p2)
    : Parabola_2< Gt >(p, l)
  {
    this->p1 = Point_2(to_double(p1.x()), to_double(p1.y()));
    this->p2 = Point_2(to_double(p1.x()), to_double(p1.y()));
  }

  Parabola_segment_2(const typename Gt::Point_2 &p, const typename Gt::Line_2 &l,
		     const typename Gt::Point_2 &p1, const typename Gt::Point_2 &p2)
    : Parabola_2< Gt >(p, l)
  {
    this->p1 = Point_2(to_double(p1.x()), to_double(p1.y()));
    this->p2 = Point_2(to_double(p1.x()), to_double(p1.y()));
  }

  int compute_k(const FT& tt) const {
    //    return int(CGAL::to_double(CGAL::sqrt(tt / this->STEP())));
    return int(CGAL::sqrt(CGAL::to_double(tt) / CGAL::to_double(this->STEP())));
  }

  void generate_points(std::vector<Point_2>& p) const
  {
    FT s0, s1;

    s0 = Parabola_2<Gt>::t(p1);
    s1 = Parabola_2<Gt>::t(p2);

    if (CGAL::compare(s0, s1) == LARGER) {
      std::swap(s0, s1);
    }

    p.clear();

    if ( !(CGAL::is_positive(s0)) &&
	 !(CGAL::is_negative(s1)) ) {
      FT tt;
      int k;

      p.push_back( this->o );
      k = -1;
      tt = -this->STEP();
      while ( CGAL::compare(tt, s0) == LARGER ) {
	p.insert( p.begin(), Parabola_2<Gt>::f(tt) );
	k--;
	tt = -FT(k * k) * this->STEP();
      }
      p.insert( p.begin(), Parabola_2<Gt>::f(s0) );

      k = 1;
      tt = this->STEP();
      while ( CGAL::compare(tt, s1) == SMALLER ) {
	p.push_back( Parabola_2<Gt>::f(tt) );
	k++;
	tt = FT(k * k) * this->STEP();
      }
      p.push_back( Parabola_2<Gt>::f(s1) );
    } else if ( !(CGAL::is_negative(s0)) &&
		!(CGAL::is_negative(s1)) ) {
      FT tt;
      int k;


      p.push_back( Parabola_2<Gt>::f(s0) );

      tt = s0;
      k = compute_k(tt);

      while ( CGAL::compare(tt, s1) == SMALLER ) {
	if ( CGAL::compare(tt, s0) != SMALLER )
	  p.push_back( Parabola_2<Gt>::f(tt) );
	k++;
	tt = FT(k * k) * this->STEP();
      }
      p.push_back( Parabola_2<Gt>::f(s1) );
    } else {
      FT tt;
      int k;

      p.push_back( Parabola_2<Gt>::f(s1) );

      tt = s1;
      k = -compute_k(-tt);

      while ( CGAL::compare(tt, s0) == LARGER ) {
	if ( CGAL::compare(tt, s1) != LARGER )
	  p.push_back( Parabola_2<Gt>::f(tt) );
	k--;
	tt = -FT(k * k) * this->STEP();
      }
      p.push_back( Parabola_2<Gt>::f(s0) );
    }
  }


  template< class Stream >
  void draw(Stream& W) const
  {
    std::vector< Point_2 > p;
    generate_points(p);

    for (unsigned int i = 0; i < p.size() - 1; i++) {
      W << Segment_2(p[i], p[i+1]);
    }
  }
};



template< class Stream, class Gt >
inline
Stream& operator<<(Stream &s, const Parabola_segment_2<Gt> &P)
{
  P.draw(s);
  return s;
}

CGAL_END_NAMESPACE

#endif // CGAL_PARABOLA_SEGMENT_2_H
