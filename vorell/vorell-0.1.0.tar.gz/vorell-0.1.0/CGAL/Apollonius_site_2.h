// Copyright (c) 2003,2004  INRIA Sophia-Antipolis (France).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you may redistribute it under
// the terms of the Q Public License version 1.0.
// See the file LICENSE.QPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $URL: svn+ssh://scm.gforge.inria.fr/svn/cgal/branches/CGAL-3.3-branch/Apollonius_graph_2/include/CGAL/Apollonius_site_2.h $
// $Id: Apollonius_site_2.h 31299 2006-05-27 10:38:38Z mkaravel $
// 
//
// Author(s)     : Menelaos Karavelas <mkaravel@cse.nd.edu>

// Modified by George M. Tzoumas for the Voronoi Diagram of Ellipses

#ifndef CGAL_APOLLONIUS_SITE_2_H
#define CGAL_APOLLONIUS_SITE_2_H

#include <iostream>
#include <CGAL/basic.h>

#include <CGAL/Apollonius_graph_2/short_names_2.h>

#ifdef ASSERT
#define ASSERT_OLD ASSERT
#undef ASSERT
#endif

#ifdef DEBUG
#define DEBUG_OLD DEBUG
#undef DEBUG
//#define DEBUG 0
#endif

#include "ellipses/ellipse.h"

#ifdef DEBUG_OLD
#undef DEBUG
#define DEBUG DEBUG_OLD
#endif

#ifdef ASSERT_OLD
#undef ASSERT
#define ASSERT ASSERT_OLD
#endif

#define tQQ(x) QQ(ZZ((x).numerator().mpz()), ZZ((x).denominator().mpz())) 
#define tFT(x) Rep::FT(x.get_num().get_mpz_t(), x.get_den().get_mpz_t()) 
//#define tFTs(x) FT(x.get_num().get_mpz_t(), x.get_den().get_mpz_t()) 

CGAL_BEGIN_NAMESPACE

template < class K >
class Apollonius_site_2: public Ellipse
{
public:
  typedef K                       Kernel;
  typedef typename K::Point_2     Point_2;
  typedef Apollonius_site_2<K>    Self;
  typedef typename K::FT          Weight;
  typedef typename K::RT          RT;
  typedef Weight                  FT;


public:
  Apollonius_site_2(const Point_2& p = Point_2(),
		    const Weight& w = Weight(0))
    : Ellipse(tQQ(w), tQQ(w), 0, tQQ(p.x()), tQQ(p.y())), _p(p), _w(w) {
//    std::cerr << Ellipse(*this) << std::endl;
    }

  Apollonius_site_2(const Apollonius_site_2& other)
    : Ellipse(other), _p(other._p), _w(other._w) {
//    std::cerr << Ellipse(*this) << std::endl;
  }
  
  Apollonius_site_2(const Ellipse &ell): Ellipse(ell) { _p = Point_2(x(), y()); _w = FT(0); }
//_w = tFTs(get_fake_weight());
  
  const Point_2& point() const { return _p; }
  const Weight&  weight() const { return _w; }
  RT      x() const { return RT(get_xc().get_num().get_mpz_t(), get_xc().get_den().get_mpz_t()); }
  RT      y() const { return RT(get_yc().get_num().get_mpz_t(), get_yc().get_den().get_mpz_t()); }

  bool operator==(const Apollonius_site_2& other) const
  {
    return ( get_xc() == other.get_xc() && get_yc() == other.get_yc() && _w == _w );
  }

private:
  Point_2 _p;
  Weight  _w;

};

/*template <class K>
std::ostream&
operator<<(std::ostream &os, const Apollonius_site_2<K>& wp)
{
  return os << Ellipse(wp);
}

template <class K>
std::istream&
operator>>(std::istream& is, Apollonius_site_2<K>& wp)
{
  typename Apollonius_site_2<K>::Weight   weight;
  typename Apollonius_site_2<K>::Point_2  p;
  is >> p >> weight;
  wp = Apollonius_site_2<K>(p, weight);
  return is;
}*/


CGAL_END_NAMESPACE

#endif // CGAL_APOLLONIUS_SITE_2_H

