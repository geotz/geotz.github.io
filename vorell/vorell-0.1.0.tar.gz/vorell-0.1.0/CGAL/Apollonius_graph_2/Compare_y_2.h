// Copyright (c) 2003,2004,2006  INRIA Sophia-Antipolis (France).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you may redistribute it under
// the terms of the Q Public License version 1.0.
// See the file LICENSE.QPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $URL: svn+ssh://scm.gforge.inria.fr/svn/cgal/branches/CGAL-3.3-branch/Apollonius_graph_2/include/CGAL/Apollonius_graph_2/Compare_y_2.h $
// $Id: Compare_y_2.h 32650 2006-07-20 14:46:46Z mkaravel $
// 
//
// Author(s)     : Menelaos Karavelas <mkaravel@cse.nd.edu>



#ifndef CGAL_APOLLONIUS_GRAPH_2_COMPARE_Y_2_H
#define CGAL_APOLLONIUS_GRAPH_2_COMPARE_Y_2_H

#include <CGAL/Apollonius_graph_2/basic.h>

//--------------------------------------------------------------------

CGAL_BEGIN_NAMESPACE

CGAL_APOLLONIUS_GRAPH_2_BEGIN_NAMESPACE

template<class K>
class Compare_y_2
{
public:
  typedef K                              Kernel;
  typedef typename K::Site_2             Site_2;

  typedef typename K::Comparison_result  result_type;
  typedef Arity_tag<2>                   Arity;
  typedef Site_2                         argument_type;

  inline
  result_type operator()(const Site_2& s1, const Site_2& s2) const
  {
#ifdef COMPARE
    result_type men = CGAL::compare(s1.y(), s2.y());
#endif
    
    result_type r = (result_type) mmx::compare(s1.get_yc(), s2.get_yc());
    
#ifdef COMPARE
    if (men != r) {
        std::cerr << "BUG:compare_y(s1, s2)\n";
        std::cerr << "APOLLONIUS = " << men << std::endl;
        std::cerr << "ELLIPSES = " << men << std::endl;
        std::cerr << s1 << std::endl;
        std::cerr << s2 << std::endl;
    }
#endif
    return r;
  }
};

//--------------------------------------------------------------------

CGAL_APOLLONIUS_GRAPH_2_END_NAMESPACE

CGAL_END_NAMESPACE

#endif // CGAL_APOLLONIUS_GRAPH_2_COMPARE_Y_2_H
