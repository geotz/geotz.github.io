// Copyright (c) 2003,2004  INRIA Sophia-Antipolis (France).
// All rights reserved.
//
// This file is part of CGAL (www.cgal.org); you may redistribute it under
// the terms of the Q Public License version 1.0.
// See the file LICENSE.QPL distributed with CGAL.
//
// Licensees holding a valid commercial license may use this file in
// accordance with the commercial license agreement provided with the software.
//
// This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
// WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
//
// $URL: svn+ssh://scm.gforge.inria.fr/svn/cgal/branches/CGAL-3.3-branch/Apollonius_graph_2/include/CGAL/Apollonius_graph_2/Is_degenerate_edge_C2.h $
// $Id: Is_degenerate_edge_C2.h 33210 2006-08-10 09:03:31Z mkaravel $
// 
//
// Author(s)     : Menelaos Karavelas <mkaravel@cse.nd.edu>



#ifndef CGAL_APOLLONIUS_GRAPH_2_IS_DEGENERATE_EDGE_C2_H
#define CGAL_APOLLONIUS_GRAPH_2_IS_DEGENERATE_EDGE_C2_H

#include <CGAL/Apollonius_graph_2/basic.h>

#include <CGAL/Apollonius_graph_2/Predicate_constructions_C2.h>

#include <CGAL/Apollonius_graph_2/Incircle_C2.h>
#include <CGAL/Apollonius_graph_2/Finite_edge_test_C2.h>

CGAL_BEGIN_NAMESPACE

CGAL_APOLLONIUS_GRAPH_2_BEGIN_NAMESPACE


//--------------------------------------------------------------------

template < class K, class MTag >
class Is_degenerate_edge_2
{
public:
  typedef K                                 Kernel;
  typedef MTag                              Method_tag;

  typedef typename K::Site_2                Site_2;
#ifdef COMPARE
  typedef Weighted_point_inverter_2<K>      Weighted_point_inverter;
  typedef Inverted_weighted_point_2<K>      Inverted_weighted_point;
  typedef Bitangent_line_2<K>               Bitangent_line;
  typedef Voronoi_circle_2<K>               Voronoi_circle;
#endif
  
  typedef typename K::FT                    FT;
  typedef typename K::Sign                  Sign;
  typedef typename K::Comparison_result     Comparison_result;

#ifdef COMPARE
  typedef Order_on_finite_bisector_2<K>     Order_on_finite_bisector;

  typedef Sign_of_distance_from_CCW_circle_2<K>
                                          Sign_of_distance_from_CCW_circle;
#endif

public:
  typedef Site_2             argument_type;
  typedef bool               result_type;
  typedef Arity_tag<4>       Arity;

  bool operator()(const Site_2& p1, const Site_2& p2,
		  const Site_2& p3, const Site_2& p4) const
  {
    Method_tag tag;
    
    Sign s;

#ifdef COMPARE
    Sign men_s;
    Weighted_point_inverter inverter(p1);
    Inverted_weighted_point u2 = inverter(p2);
    Inverted_weighted_point u3 = inverter(p3);
    Inverted_weighted_point u4 = inverter(p4);

    Bitangent_line blinv_23(u2, u3);
    men_s = Sign_of_distance_from_CCW_circle()(blinv_23, u4, tag);
#endif
    
    s = (Sign) in_circle(p1, p2, p3, p4);

#ifdef COMPARE
    if (s != men_s) {
        std::cerr << "BUG:is_degen_edge(p1,p2,p3,p4)\n" << std::endl;
        std::cerr << p1 << std::endl;
        std::cerr << p2 << std::endl;
        std::cerr << p3 << std::endl;
        std::cerr << p4 << std::endl;
        abort();
    }
#endif   
        
    if ( s != ZERO ) { return false; }

#ifdef COMPARE
    Bitangent_line blinv_42(u4, u2);
    men_s = Sign_of_distance_from_CCW_circle()(blinv_42, u3, tag);
#endif
    
    s = (Sign) in_circle(p1,p4,p2,p3);
    
#ifdef COMPARE
    if (s != men_s) {
        std::cerr << "BUG:is_degen_edge(p1,p4,p2,p3)\n" << std::endl;
        std::cerr << p1 << std::endl;
        std::cerr << p2 << std::endl;
        std::cerr << p3 << std::endl;
        std::cerr << p4 << std::endl;
        abort();
    }
#endif   
        
    
    if ( s != ZERO ) { return false; }

#ifdef COMPARE
    Voronoi_circle vc_123(blinv_23);
    Voronoi_circle vc_142(blinv_42);
    Comparison_result men_r =
      Order_on_finite_bisector()(vc_123, vc_142, p1, p2, tag);
#endif
    
    EllipseTriplet e123(p1, p2, p3), e142(p1, p4, p2);
    Comparison_result r = (Comparison_result) order_on_finite_bisector(e123.voronoi_circle(), e142.voronoi_circle(), p1, p2);

#ifdef COMPARE      
      if (men_r != r) {
          std::cerr << "BUG: is_degen_edge/order_on_finite_bisector!, line " << __LINE__ << std::endl;
          std::cerr << "APOLLONIUS = " << men_r << std::endl;
          std::cerr << "ELLIPSES = " << r << std::endl;
          std::cerr << p1 << std::endl;
          std::cerr << p2 << std::endl;
          std::cerr << p3 << std::endl;
          std::cerr << p4 << std::endl;
          abort();
      }
#endif

    return ( r == EQUAL );
  }
};

//--------------------------------------------------------------------

CGAL_APOLLONIUS_GRAPH_2_END_NAMESPACE

CGAL_END_NAMESPACE

#endif // CGAL_APOLLONIUS_GRAPH_2_IS_DEGENERATE_EDGE_C2_H
