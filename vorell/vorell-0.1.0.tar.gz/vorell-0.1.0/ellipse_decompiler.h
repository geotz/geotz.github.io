/*
    National University of Athens
    Department of Informatics and Telecommunications
    
    Voronoi diagram of Ellipses
    (c) 2007 George M. Tzoumas
    
    THIS SOURCE CODE IS PROVIDED WITHOUT ANY WARRANTY.
    YOU ARE FREE TO USE THIS CODE, BUT PROPER CREDITS MUST BE GIVEN.
*/

#ifndef ELLIPSE_DECOMPILER_H
#define ELLIPSE_DECOMPILER_H

#include "typedefs.h"

#include "ellipses/algebra.h"
#include "ellipses/bisectorx.h"
#include <subdivix/sleeve_approx.hpp>

class EllipseDecompiler {
    typedef CGAL::Conic_2<Rep>                    Conic_2;
    
    double a, b, w, xc, yc;
    QQ qa, qb, qw, qxc, qyc;
    Ellipse ell;
    Rep::FT rationalize(double x) {
        return CGAL::simplest_rational_in_interval<Rep::FT>(x-0.001,x+0.001);
    }
    
public:
    EllipseDecompiler() { }
        
    EllipseDecompiler(Conic_2 &c) {
        assert(c.is_ellipse());
        double ac[6];
        std::cerr << c << std::endl;
        ac[0] = to_double(c.r());
        ac[1] = to_double(c.t())/2.0;
        ac[2] = to_double(c.s());
        ac[3] = to_double(c.u())/2.0;
        ac[4] = to_double(c.v())/2.0;
        ac[5] = to_double(c.w());
        double mc = 0;
        for (int i = 0; i < 6; i++) if (abs(ac[i]) > mc) mc = abs(ac[i]);
        for (int i = 0; i < 6; i++) ac[i] /= mc;
/*        ac[0] /= ac[5];
        ac[1] /= ac[5];
        ac[2] /= ac[5];
        ac[3] /= ac[5];
        ac[4] /= ac[5];
        ac[5] = 1.0;*/
        
        double j2 = ac[1]*ac[1] - ac[0]*ac[2];
        xc = (ac[2]*ac[3] - ac[1]*ac[4]) / j2;
        yc = (ac[0]*ac[4] - ac[1]*ac[3]) / j2;
        
        double j3 = ac[0]*ac[4]*ac[4]+ac[2]*ac[3]*ac[3]+ac[5]*ac[1]*ac[1]-2*ac[1]*ac[3]*ac[4]-ac[0]*ac[2]*ac[5];
        
        a = sqrt((2*j3)/((j2)*((ac[0]-ac[2])*sqrt(1+(4*ac[1]*ac[1])/((ac[0]-ac[2])*(ac[0]-ac[2])))-(ac[2]+ac[0]))));
        b = sqrt((2*j3)/((j2)*((ac[2]-ac[0])*sqrt(1+(4*ac[1]*ac[1])/((ac[0]-ac[2])*(ac[0]-ac[2])))-(ac[2]+ac[0]))));
        if (a < b) {
            double t = a;
            a = b;
            b = t;
        }
        
        double a2 = a*a;
        double b2 = b*b;
        double v = ac[0]/ac[1];
        
        upolx_t wpol(5, AsSize());
        wpol[0] = b2;
        wpol[1] = 2*v*(a2-b2);
        wpol[2] = 2*(2*a2-b2);
        wpol[3] = 2*v*(a2-b2);
        wpol[4] = b2;
        double cb = cauchy_bound(wpol);
        Seq<double> sol = mmx::solve(wpol, SlvBzBdg<double>(), -cb, cb);
        std::cerr << sol << std::endl;
        double bvv = 1e6;
        int bi = 0;
        for (int i = 0; i < sol.size(); i++) {
            double xx = to_double(ellipse_x(INTERVAL(a), INTERVAL(b), INTERVAL(sol[i]), INTERVAL(xc), INTERVAL(yc), 0));
            double yy = to_double(ellipse_y(INTERVAL(a), INTERVAL(b), INTERVAL(sol[i]), INTERVAL(xc), INTERVAL(yc), 0));
            double vv = ac[0]*xx*xx + 2*ac[1]*xx*yy + ac[2]*yy*yy + 2*ac[3]*xx + 2*ac[4]*yy + ac[5];
            if (abs(vv) < bvv) bvv = abs(vv), bi = i;
            std::cerr << "eval(" << xx << "," << yy << ") = " << vv << std::endl; 
        }
        w = sol[bi];
        std::cerr << "decompiled ellipse to " << a << " x " << b << " % " << w << " @ (" << xc << "," << yc << ")" << std::endl;
        qa = tQQ(rationalize(a));
        qb = tQQ(rationalize(b));
        qw = tQQ(rationalize(w));
        qxc = tQQ(rationalize(xc));
        qyc = tQQ(rationalize(yc));
        ell = Ellipse(qa, qb, qw, qxc, qyc);
        std::cerr << ell << std::endl;  
        ell.print_eq(std::cerr);
        std::cerr << std::endl;
    }
    
    EllipseDecompiler(Ellipse &e): ell(e) { }

    EllipseDecompiler(QQ qx1, QQ qy1, QQ qx2, QQ qy2, QQ qx3, QQ qy3) { 
        double x1 = to_double(qx1);
        double x2 = to_double(qx2);
        double x3 = to_double(qx3);
        double y1 = to_double(qy1);
        double y2 = to_double(qy2);
        double y3 = to_double(qy3);
        double xa = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
        double xb = sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));;
        qa = tQQ(rationalize(xa));
        qb = tQQ(rationalize(xb));
        double dy = y2-y1;
        double dx = x2-x1;
        if (abs(dx) < 1e-6) {
            qw = QQ(0);
            QQ tmp = qa; qa = qb; qb = tmp;
        } else {
            qw = tQQ(rationalize(std::tan(std::atan2(dy,dx)/2.0)));
        }
        ell = Ellipse(qa, qb, qw, qx1, qy1);

        std::cerr << ell << std::endl;  
        ell.print_eq(std::cerr);
        std::cerr << std::endl;
    }
    
    Conic_2 get_conic() const { 
        return Conic_2(tFT(ell.get_alg_coeff(0)), tFT(ell.get_alg_coeff(2)), tFT(QQ(ell.get_alg_coeff(1)*2)), 
                tFT(QQ(ell.get_alg_coeff(3)*2)), tFT(QQ(ell.get_alg_coeff(4)*2)), tFT(ell.get_alg_coeff(5)));
    }
    
    Ellipse get_ellipse() const { return ell; }
};


#endif
