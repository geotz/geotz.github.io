MSPACMAN by George M. Tzoumas
demo version

usage:
 mspacman r (for wait retrace)
 mspacman d (for delay)
 mspacman   (for MHZ disaster !!)

cheat:
 #251 : score up by 1000 pts
 #252 : bonus pacman (life)
 #253 : eat a power pill
 #254 : toggle visible/invisible mode
 #255 : skip level
