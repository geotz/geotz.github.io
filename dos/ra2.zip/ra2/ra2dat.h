/* Allegro datafile object indexes, produced by dat v3.12 */
/* Datafile: ra2.dat */
/* Date: Thu Jul 13 17:11:41 2000 */
/* Do not hand edit! */

#define TINY_FONT                        0        /* FONT */

